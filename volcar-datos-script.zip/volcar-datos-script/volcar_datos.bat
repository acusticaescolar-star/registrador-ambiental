@echo off
chcp 65001 >nul
REM ============================================================
REM volcar_datos.bat
REM Lanzador del volcado de datos del Registrador Ambiental
REM www.acusticaescolar.com - Licencia MIT
REM
REM Uso normal:      doble clic en este fichero
REM Puerto manual:   volcar_datos.bat COM3
REM Diagnostico:     volcar_datos.bat COM3 -Verbose
REM
REM chcp 65001 pone la consola en UTF-8 para que los acentos
REM se muestren correctamente.
REM ============================================================
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0volcar_datos.ps1" -Puerto "%~1" %2
