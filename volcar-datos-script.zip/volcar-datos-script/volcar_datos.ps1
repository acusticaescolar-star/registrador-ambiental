﻿# ============================================================
# volcar_datos.ps1
# Vuelca el CSV del Registrador Ambiental a un fichero en el PC
# www.acusticaescolar.com - Licencia MIT
#
# Usó normal:     doble clic en volcar_datos.bat
# Puerto manual:  volcar_datos.bat COM3
# Diagnóstico:    volcar_datos.bat COM3 -Verbose
#
# IMPORTANTE: el Monitor Serie del Arduino IDE debe estar CERRADO.
# ============================================================

param(
    [string]$Puerto = "",
    [switch]$Verbose
)

$ErrorActionPreference = "Stop"
$baudRate = 115200

# La consola de Windows no usa UTF-8 por defecto: sin esto los acentos
# se muestran como caracteres extraños.
try {
    [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
    $OutputEncoding = [System.Text.Encoding]::UTF8
} catch { }

# ── Umbrales de valoración ──
# Se leen de umbrales.txt, en la misma carpeta. Si no existe, se crea con
# los valores por defecto. Así pueden actualizarse sin tocar este script.
$umbralesPorDefecto = @{
    T_MIN_LEGAL=17; T_OPTIMO_MIN=20; T_OPTIMO_MAX=24; T_MAX_LEGAL=27; T_RIESGO=30
    HR_MIN_LEGAL=30; HR_OPTIMO_MIN=40; HR_OPTIMO_MAX=60; HR_MAX_LEGAL=70
    CO2_OPTIMO=700; CO2_ACEPTABLE=900; CO2_DEFICIENTE=1200; CO2_RIESGO=1600
    DB_OPTIMO=35; DB_ACEPTABLE=45; DB_NORMAL=55; DB_RIESGO=65
}
function Get-Franjas {
    $f = Join-Path $PSScriptRoot "franjas.txt"
    $lista = @()
    if (Test-Path $f) {
        foreach ($l in (Get-Content $f -Encoding UTF8)) {
            # El .Trim([char]0xFEFF) quita la marca de orden de bytes que
            # Windows PowerShell 5.1 deja pegada a la primera línea: no es
            # espacio en blanco para .NET, así que Trim() sola no la elimina.
            $l = $l.Trim().Trim([char]0xFEFF).Trim()
            if ($l -eq "" -or $l.StartsWith("#")) { continue }
            if ($l -match "^(\d{1,2}):(\d{2})\s*-\s*(\d{1,2}):(\d{2})\s*=\s*(.+)$") {
                # OJO: capturar ini/fin de $Matches AQUÍ, antes de cualquier otro
                # -match. $Matches es una única variable automática que el chequeo
                # de *VACÍO de abajo sobrescribe; leerla después devolvía $null en
                # los grupos 1-4 y colapsaba TODAS las franjas vacías a ini=fin=0
                # (medianoche), invalidando el reparto exógeno/endógeno y el eje
                # estructural (RT/STI/fondo) para cualquier franja marcada *VACÍO.
                $iniMin = [int]$Matches[1]*60 + [int]$Matches[2]
                $finMin = [int]$Matches[3]*60 + [int]$Matches[4]
                $nom = $Matches[5].Trim()
                $vacio = $false
                if ($nom -match "\*VAC[IÍÃ]\S*O\s*$") {
                    $vacio = $true
                    $nom = ($nom -replace "\*VAC[IÍÃ]\S*O\s*$", "").Trim()
                }
                $lista += [PSCustomObject]@{
                    ini = $iniMin
                    fin = $finMin
                    nombre = $nom
                    vacio = $vacio
                }
            }
        }
    }
    return $lista
}

function Get-Umbrales {
    $f = Join-Path $PSScriptRoot "umbrales.txt"
    $u = $umbralesPorDefecto.Clone()
    if (Test-Path $f) {
        foreach ($l in (Get-Content $f -Encoding UTF8)) {
            $l = $l.Trim().Trim([char]0xFEFF).Trim()   # ver nota en Get-Franjas
            if ($l -eq "" -or $l.StartsWith("#")) { continue }
            if ($l -match "^([A-Z0-9_]+)\s*=\s*(-?\d+(\.\d+)?)") {
                $u[$Matches[1]] = [double]$Matches[2]
            }
        }
    }
    return $u
}

Write-Host ""
Write-Host "=== VOLCADO DE DATOS - Registrador Ambiental ===" -ForegroundColor Cyan
Write-Host ""

# ── Localizar puertos candidatos ──
function Get-Candidatos {
    $lista = @()
    try {
        $disp = Get-CimInstance -ClassName Win32_PnPEntity -ErrorAction SilentlyContinue |
                Where-Object { $_.Name -match "\(COM(\d+)\)" }
        foreach ($d in $disp) {
            if ($d.Name -match "\(COM(\d+)\)") {
                $lista += [PSCustomObject]@{
                    Com         = "COM" + $Matches[1]
                    Nombre      = $d.Name
                    Prioritario = ($d.DeviceID -match "VID_(303A|1A86|10C4|0403)")
                }
            }
        }
    } catch { }
    # Fabricante conocido primero
    return @($lista | Where-Object { $_.Prioritario }) +
           @($lista | Where-Object { -not $_.Prioritario })
}

# ── Abrir puerto y esperar a que el dispositivo este LISTO ──
# Al abrir el puerto, la placa puede reiniciarse (señal DTR). Si eso ocurre,
# el firmware ejecuta su diagnóstico de arranque durante unos segundos y no
# atiende comandos. Esta función espera a que termine antes de continuar.
function Open-Registrador {
    param([string]$com)

    $sp = New-Object System.IO.Ports.SerialPort $com, $baudRate, "None", 8, "One"
    $sp.ReadTimeout  = 1500
    $sp.WriteTimeout = 2000
    $sp.DtrEnable = $true
    $sp.RtsEnable = $true
    $sp.ReadBufferSize = 65536      # holgado: el volcado puede ser largo
    $sp.Open()

    Write-Host "      esperando a que el equipo este listo..." -ForegroundColor Gray
    $arrancando = $false
    $listo      = $false
    $limite = (Get-Date).AddSeconds(30)

    while ((Get-Date) -lt $limite) {
        try { $l = $sp.ReadLine().TrimEnd("`r") }
        catch [TimeoutException] {
            # Silencio: si ya vimos el arranque, es que termino; si no, probamos
            if ($arrancando) { $listo = $true; break }
            $sp.WriteLine("H")       # tantear con un comando inofensivo
            continue
        }
        if ($Verbose) { Write-Host "        < $l" -ForegroundColor DarkGray }

        # El equipo se ha reiniciado: hay que esperar al final del diagnóstico
        if ($l -match "DATALOGGER AMBIENTAL|FASE 1|Iniciando") { $arrancando = $true }
        # Señales de que ya esta operativo y atiende comandos
        if ($l -match "Comandos:|componentes OK|Hora del RTC|\[LOG #|Ventana de registro") {
            $listo = $true; break
        }
    }
    if (-not $listo) { Write-Host "      (sin confirmación, se intenta igualmente)" -ForegroundColor DarkYellow }
    Start-Sleep -Milliseconds 500
    $sp.DiscardInBuffer()
    return $sp
}

# ── Determinar el puerto ──
if ($Puerto -ne "") {
    $puertoElegido = $Puerto
    Write-Host "[i] Puerto indicado manualmente: $puertoElegido" -ForegroundColor Yellow
} else {
    $cand = Get-Candidatos
    if ($cand.Count -eq 0) {
        Write-Host "[!] No se ha detectado ningún puerto COM." -ForegroundColor Red
        Write-Host "    Verifica que el registrador esta conectado por USB." -ForegroundColor Yellow
        Read-Host "`nPulsa Enter para salir"; exit 1
    }
    Write-Host "[i] Puertos detectados:" -ForegroundColor Cyan
    foreach ($c in $cand) {
        $m = if ($c.Prioritario) { " <- chip USB-serie conocido" } else { "" }
        Write-Host "      $($c.Nombre)$m" -ForegroundColor Gray
    }
    $puertoElegido = $cand[0].Com
    Write-Host ""
    Write-Host "[i] Usando $puertoElegido" -ForegroundColor Cyan
}

# ── Abrir (una sola vez) ──
try {
    $sp = Open-Registrador $puertoElegido
} catch {
    Write-Host ""
    Write-Host "[!] No se pudo abrir $puertoElegido." -ForegroundColor Red
    Write-Host "    Causas más probables:" -ForegroundColor Yellow
    Write-Host "      - El Monitor Serie del Arduino IDE esta abierto. Ciérralo." -ForegroundColor Yellow
    Write-Host "      - Otro programa esta usando el puerto." -ForegroundColor Yellow
    Write-Host "    Puedes indicar otro puerto:  volcar_datos.bat COM3" -ForegroundColor White
    Read-Host "`nPulsa Enter para salir"; exit 1
}

Write-Host "[OK] Conectado a $puertoElegido" -ForegroundColor Green
Write-Host ""

# ── Solicitar el volcado (con reintentos) ──
$lineas = New-Object System.Collections.Generic.List[string]
$recibidoAlgo = $false

for ($intento = 1; $intento -le 3; $intento++) {
    Write-Host "[i] Solicitando volcado del CSV (intento $intento de 3)..." -ForegroundColor Cyan
    $sp.DiscardInBuffer()
    $sp.WriteLine("D")

    $capturando = $false
    $sp.ReadTimeout = 5000
    $limite = (Get-Date).AddSeconds(90)

    while ((Get-Date) -lt $limite) {
        try { $linea = $sp.ReadLine().TrimEnd("`r") }
        catch [TimeoutException] { if ($capturando) { break } else { break } }
        $recibidoAlgo = $true
        if ($Verbose) { Write-Host "    < $linea" -ForegroundColor DarkGray }

        if ($linea -match "----- INICIO CSV -----") { $capturando = $true; continue }
        if ($linea -match "----- FIN CSV")          { break }
        if ($linea -match "No hay CSV") {
            Write-Host "[!] El equipo responde que no hay datos guardados." -ForegroundColor Yellow
            $sp.Close(); Read-Host "`nPulsa Enter para salir"; exit 1
        }
        if ($capturando -and $linea -notmatch "^\[LOG #") { $lineas.Add($linea) }
    }
    if ($lineas.Count -gt 0) { break }
    Write-Host "      sin respuesta útil, reintentando..." -ForegroundColor DarkYellow
    Start-Sleep -Seconds 2
}
$sp.Close()

if ($lineas.Count -eq 0) {
    Write-Host ""
    Write-Host "[!] No se recibieron datos." -ForegroundColor Red
    if ($recibidoAlgo) {
        Write-Host "    El equipo respondía, pero no envió el bloque de datos." -ForegroundColor Yellow
        Write-Host "    Comprueba con el comando I (en el Monitor Serie) que hay" -ForegroundColor Yellow
        Write-Host "    registros guardados." -ForegroundColor Yellow
    } else {
        Write-Host "    El equipo no respondió en absoluto." -ForegroundColor Yellow
        Write-Host "    Prueba a desconectar y reconectar el cable USB." -ForegroundColor Yellow
    }
    Write-Host ""
    Write-Host "    Para ver el detalle de la comunicación:" -ForegroundColor White
    Write-Host "      volcar_datos.bat $puertoElegido -Verbose" -ForegroundColor White
    Read-Host "`nPulsa Enter para salir"; exit 1
}

# ── Análisis de los datos ──
# Segmenta por ESPACIO (marcas #ESPACIO del CSV), luego por DÍA y dentro de
# cada día por FRANJA horaria. Es la estructura que corresponde a la operativa
# real: el equipo pasa uno o dos días en cada aula, y dentro del día el uso
# del espacio cambia (clase, recreo, comedor, vacío).

function Stats($vals) {
    if ($vals.Count -eq 0) { return $null }
    $m = ($vals | Measure-Object -Minimum -Maximum -Average)
    return @{ min=$m.Minimum; max=$m.Maximum; avg=$m.Average; n=$vals.Count }
}
function Pct($k, $tot) { if ($tot -eq 0) { return 0 } return $k*100/$tot }

# Resta energética de dos niveles en dB: cuánto aporta una fuente adicional
# sobre un fondo conocido. Devuelve $null si el total no supera al fondo.
function RestaEnergetica($total, $fondo) {
    if ($total -le $fondo) { return $null }
    $d = [math]::Pow(10, $total/10.0) - [math]::Pow(10, $fondo/10.0)
    if ($d -le 0) { return $null }
    return 10*[math]::Log10($d)
}

# Peso relativo de una fuente sobre la energía total (porcentaje)
function PesoEnergetico($parte, $total) {
    if ($total -le 0) { return 0 }
    return [math]::Pow(10, $parte/10.0) / [math]::Pow(10, $total/10.0) * 100
}

# ── Reparto exógeno/endógeno CON BANDA (revision-rigor-2.md, hallazgo 18) ──
# La resta energética de dos niveles próximos amplifica cualquier error: con
# una incertidumbre de +/-2 dB en cada nivel, el "% exterior" de una misma aula
# puede moverse decenas de puntos. Presentarlo con un decimal sugiere una
# resolución que el dato no tiene.
#
# Se calculan los dos extremos razonables:
#   - peso exterior MÁXIMO: la referencia lo más alta posible y el total lo más
#     bajo posible (ref+u, total-u)
#   - peso exterior MÍNIMO: al revés (ref-u, total+u)
# y se decide qué se puede afirmar:
#   'cifra'       la banda es estrecha: se da el rango numérico
#   'cualitativo' la banda es ancha pero permite decir de qué lado cae
#   'nada'        el total no supera a la referencia por encima de la
#                 incertidumbre: no hay reparto que sostener
function RepartoConBanda($lqTotal, $lqRef, $u = 2.0) {
    if ($lqTotal -eq $null -or $lqRef -eq $null) { return $null }
    $res = @{ total = $lqTotal; ref = $lqRef; u = $u }
    if (($lqTotal - $lqRef) -le $u) {
        $res.tipo = 'nada'
        return $res
    }
    $pAlto = PesoEnergetico ([math]::Min($lqRef + $u, $lqTotal - $u)) ($lqTotal - $u)
    $pBajo = PesoEnergetico ($lqRef - $u) ($lqTotal + $u)
    $pAlto = [math]::Min($pAlto, 100); $pBajo = [math]::Max($pBajo, 0)
    $res.lo = [math]::Min($pBajo, $pAlto)
    $res.hi = [math]::Max($pBajo, $pAlto)
    $res.punto = PesoEnergetico $lqRef $lqTotal
    $res.endo  = RestaEnergetica $lqTotal $lqRef
    if (($res.hi - $res.lo) -le 20) { $res.tipo = 'cifra' }
    else { $res.tipo = 'cualitativo' }
    return $res
}

# Texto de una línea de reparto, coherente con lo que la banda permite afirmar.
function TextoReparto($nombre, $r) {
    if ($r -eq $null) { return $null }
    switch ($r.tipo) {
        'nada' {
            return ("    {0,-22} total {1,5:N1} dB: no separable. El exterior de referencia ({2:N1} dB)" -f $nombre, $r.total, $r.ref)
        }
        'cifra' {
            return ("    {0,-22} total {1,5:N1} dB = actividad {2,5:N1} dB + exterior {3,5:N1} dB  ({4:N0}-{5:N0} % exterior)" -f $nombre, $r.total, $r.endo, $r.ref, $r.lo, $r.hi)
        }
        default {
            $etq = if ($r.lo -gt 60) { "mayoritariamente EXTERIOR" }
                   elseif ($r.hi -lt 40) { "mayoritariamente ACTIVIDAD" }
                   else { "mixto, no separable con esta incertidumbre" }
            return ("    {0,-22} total {1,5:N1} dB, exterior {2,5:N1} dB  ->  {3} ({4:N0}-{5:N0} %)" -f $nombre, $r.total, $r.ref, $etq, $r.lo, $r.hi)
        }
    }
}

# LAeq de un conjunto de intervalos: promedio ENERGÉTICO, no aritmético
function LaeqGlobal($filas) {
    $v = $filas | Where-Object { $_.estado -notlike "*ERR_DB*" -and $_.estado -notlike "*DB_MUESTRA_UNICA*" -and $_.estado -notlike "*DB_INCOMPLETO*" -and $_.laeq -gt 0 }
    if ($v.Count -eq 0) { return $null }
    $s = 0.0
    foreach ($f in $v) { $s += [math]::Pow(10, $f.laeq/10.0) }
    return 10*[math]::Log10($s/$v.Count)
}

# ── Punto de rocío (fórmula de Magnus-Tetens) ──
# Temperatura a la que el aire se satura. Si una superficie del aula está por
# debajo (puentes térmicos, vidrios, esquinas de fachada), aparece condensación
# y con ella riesgo de moho.
function PuntoRocio($t, $hr) {
    if ($hr -le 0 -or $hr -gt 100) { return $null }
    $a = 17.27; $b = 237.7
    $alfa = [math]::Log($hr/100.0) + ($a*$t)/($b+$t)
    return ($b*$alfa)/($a-$alfa)
}

# ── Índice de calor (Rothfusz) ──
# Temperatura percibida al combinar calor y humedad. Por debajo de 27 C o 40 %
# de humedad la corrección es despreciable y se devuelve la temperatura real.
# REVISION_RIGOR.md, hallazgo 6: la fórmula de Rothfusz (NWS) se desarrolló
# para EXTERIOR, a la sombra y con viento ligero; su aplicación a un aula
# cerrada no está validada. Se mantiene solo como indicador orientativo de
# sensación térmica -- nunca como medida de confort interior, para lo que
# haría falta UNE-EN ISO 7730 (PMV/PPD), que exige además velocidad del aire
# y estimación de vestimenta y actividad metabólica, datos de los que no se
# dispone. Ver documento de proyecto, §7.3.
function IndiceCalor($t, $hr) {
    if ($t -lt 27 -or $hr -lt 40) { return $t }
    $hi = -8.78469475556 + 1.61139411*$t + 2.33854883889*$hr `
          - 0.14611605*$t*$hr - 0.012308094*$t*$t `
          - 0.0164248277778*$hr*$hr + 0.002211732*$t*$t*$hr `
          + 0.00072546*$t*$hr*$hr - 0.000003582*$t*$t*$hr*$hr
    return $hi
}

# ── Tasa de renovación de aire (método de decaimiento, ASTM E741) ──
# El CO2 actúa como gas trazador natural: cuando el aula queda vacía, su
# concentración decae hacia el nivel exterior a un ritmo que depende de la
# ventilación. De ese decaimiento se obtienen las renovaciones por hora.
#   ACH = ln((C0 - Cext) / (Ct - Cext)) / t        [t en horas]
#
# El cálculo se hace SIEMPRE por regresión log-lineal sobre todas las lecturas
# del tramo (CalcularACHRegresion). NO hay respaldo de dos puntos: hasta la
# tercera revisión existían dos funciones para eso y un comentario que afirmaba
# que se usaban, pero no se invocaban desde ninguna parte (revision-rigor-3.md,
# hallazgo 32). Si un decaimiento no cumple los requisitos mínimos, se descarta
# y el informe dice cuántos se descartaron: es más honesto que un respaldo peor.
# El método de dos puntos se abandonó en el hallazgo 16 de la segunda revisión
# y no debe reintroducirse por parecer más simple: con dos puntos el R2 vale
# siempre 1 y el supuesto de mezcla homogénea deja de ser comprobable.

function ValorarACH($ach) {
    # Categorías del Harvard Healthy Buildings Program.
    # Las guías internacionales fijan 4 ACH como mínimo en aulas; los CDC, 5.
    if ($ach -lt 3) { return "BAJO" }
    elseif ($ach -lt 4) { return "MÍNIMO" }
    elseif ($ach -lt 5) { return "BUENO" }
    elseif ($ach -lt 6) { return "EXCELENTE" }
    else { return "IDEAL" }
}

# ── Incertidumbre del sensor de CO2 (Senseair S8: +/-40 ppm +/-3% de lectura) ──
# REVISION_RIGOR.md, hallazgo 4. Se usa para acompañar el ACH de una banda,
# en vez de presentarlo con un decimal que sugiere más precisión de la real.
function IncertidumbreCO2($ppm) {
    return 40 + 0.03 * [math]::Abs($ppm)
}

# ── ACH por REGRESIÓN log-lineal (método principal, ASTM E741) ──
# revision-rigor-2.md, hallazgo 16. El cálculo anterior usaba solo la primera y
# la última lectura del decaimiento y descartaba todas las intermedias: de una
# franja vacía de 30 min registrada cada 30 s (60 lecturas) usaba 2. ASTM E741
# no calcula así: ajusta ln(C - Cext) frente al tiempo por regresión lineal y
# toma la pendiente como tasa de renovación.
#
# La regresión aporta tres cosas que el método de dos puntos no puede dar:
#   1. Promedia el ruido de las lecturas en vez de depender de dos concretas.
#   2. El intervalo de confianza de la pendiente es una banda REAL, calculada
#      con los datos, no una aritmética de peor caso.
#   3. El R2 hace COMPROBABLE el supuesto de mezcla homogénea del hallazgo 7:
#      si el aire está bien mezclado, ln(C - Cext) es una recta; si hay
#      estratificación o cortocircuito de ventilación, la curva se aparta y el
#      R2 baja. Con dos puntos el supuesto era indemostrable por construcción,
#      porque dos puntos cualesquiera definen siempre una recta perfecta.
#
# $lecturas = objetos con .co2 y .segundos (segundos absolutos del día).
# Se ordena y se mide en SEGUNDOS, no en minutos enteros: con registro cada
# 30 s los minutos enteros cuantizaban la duración del decaimiento y dejaban
# claves repetidas, con lo que el primer y el último punto del ajuste podían no
# ser los reales (revision-rigor-2.md, hallazgo 19). -Stable mantiene además el
# orden de llegada cuando dos lecturas comparten el mismo segundo.
# Devuelve @{ ach; lo; hi; r2; n; achLoSist; achHiSist } o $null.
function CalcularACHRegresion($lecturas, $cext) {
    if ($lecturas.Count -lt 5) { return $null }
    $ord = $lecturas | Sort-Object segundos -Stable
    $t0  = $ord[0].segundos
    $mins = ($ord[$ord.Count-1].segundos - $t0) / 60.0
    if ($mins -lt 15) { return $null }
    if (($ord[0].co2 - $ord[$ord.Count-1].co2) -lt 200) { return $null }

    # Puntos (x = horas desde el inicio, y = ln(C - Cext)).
    # El ajuste se detiene cuando el exceso sobre el exterior deja de ser
    # informativo: por debajo de ese suelo la diferencia es ruido del sensor y
    # su logaritmo introduce una dispersión enorme que hundiría el R2 sin que
    # el aula tenga ningún problema de mezcla. Es la práctica habitual en los
    # ensayos de decaimiento de trazador: se ajusta mientras el trazador está
    # claramente por encima del fondo.
    $excesoIni = $ord[0].co2 - $cext
    $suelo = [math]::Max(2 * (IncertidumbreCO2 $cext), 0.10 * $excesoIni)
    $xs = @(); $ys = @()
    foreach ($r in $ord) {
        $d = $r.co2 - $cext
        if ($d -le $suelo) { break }        # a partir de aquí solo hay ruido
        $xs += ($r.segundos - $t0) / 3600.0
        $ys += [math]::Log($d)
    }
    $n = $xs.Count
    if ($n -lt 5) { return $null }

    $mx = ($xs | Measure-Object -Average).Average
    $my = ($ys | Measure-Object -Average).Average
    $sxx = 0.0; $sxy = 0.0; $syy = 0.0
    for ($i = 0; $i -lt $n; $i++) {
        $dx = $xs[$i] - $mx; $dy = $ys[$i] - $my
        $sxx += $dx*$dx; $sxy += $dx*$dy; $syy += $dy*$dy
    }
    if ($sxx -le 0) { return $null }
    $b   = $sxy / $sxx          # pendiente (negativa en un decaimiento)
    $ach = -$b                  # renovaciones por hora
    if ($ach -le 0) { return $null }
    $r2  = if ($syy -gt 0) { ($sxy*$sxy) / ($sxx*$syy) } else { 0 }

    # Intervalo de confianza al 95 % de la pendiente (t de Student ~ 2 para
    # n grande; con n >= 30, que es lo habitual, la aproximación es buena).
    $ssres = [math]::Max($syy - $b*$sxy, 0)
    $se_b  = if ($n -gt 2) { [math]::Sqrt($ssres / ($n-2) / $sxx) } else { 0 }
    $lo = $ach - 2*$se_b
    $hi = $ach + 2*$se_b

    # Componente SISTEMÁTICA: la incertidumbre de la referencia exterior no se
    # promedia con más lecturas, porque desplaza toda la curva a la vez. Se
    # evalúa rehaciendo la regresión con cext +/- su incertidumbre.
    $u = IncertidumbreCO2 $cext
    $sist = @()
    # OJO: los paréntesis de cada elemento son necesarios. En PowerShell la coma
    # liga más fuerte que la resta, y @($cext - $u, $cext + $u) se interpreta
    # como $cext - ($u, $cext) + $u, que falla en tiempo de ejecución.
    foreach ($ce in @(($cext - $u), ($cext + $u))) {
        $x2 = @(); $y2 = @()
        $suelo2 = [math]::Max(2 * (IncertidumbreCO2 $ce), 0.10 * ($ord[0].co2 - $ce))
        foreach ($r in $ord) {
            $d = $r.co2 - $ce
            if ($d -le $suelo2) { break }
            $x2 += ($r.segundos - $t0) / 3600.0
            $y2 += [math]::Log($d)
        }
        if ($x2.Count -lt 5) { continue }
        $m2x = ($x2 | Measure-Object -Average).Average
        $m2y = ($y2 | Measure-Object -Average).Average
        $s2xx = 0.0; $s2xy = 0.0
        for ($i = 0; $i -lt $x2.Count; $i++) {
            $dx = $x2[$i]-$m2x; $s2xx += $dx*$dx; $s2xy += $dx*($y2[$i]-$m2y)
        }
        if ($s2xx -gt 0) { $sist += (-($s2xy/$s2xx)) }
    }
    $achLoS = if ($sist.Count -gt 0) { ($sist | Measure-Object -Minimum).Minimum } else { $ach }
    $achHiS = if ($sist.Count -gt 0) { ($sist | Measure-Object -Maximum).Maximum } else { $ach }

    return @{ ach = $ach; lo = [math]::Max($lo,0); hi = $hi; r2 = $r2; n = $n
              durMin = $mins; c0 = $ord[0].co2; ct = $ord[$ord.Count-1].co2
              achLoSist = [math]::Min($achLoS,$achLoS); achHiSist = $achHiS }
}

# Umbral de R2 por debajo del cual el decaimiento no se comporta como una
# exponencial simple: señal de que el supuesto de mezcla homogénea (hallazgo 7)
# no se cumple en ese aula o en esa franja.
$R2_MEZCLA_MIN = 0.95

# ── Referencia exterior de CO2 (revision-rigor-2.md, hallazgo 14) ──
# Hay dos casos y NO deben presentarse igual:
#   MEDIDA    el operador anotó el CO2 al aire libre con  E ... / CEXT 420.
#             Es una referencia real y el ACH es una estimación sin sesgo
#             conocido por este concepto.
#   ESTIMADA  no hay dato exterior y se toma el mínimo interior. El interior
#             casi nunca baja hasta el exterior real, así que la referencia
#             queda por ENCIMA del valor verdadero, y en la fórmula del
#             decaimiento eso encoge el denominador más deprisa que el
#             numerador: el ACH sale ALTO. El sesgo va siempre en la dirección
#             de hacer parecer el aula mejor ventilada de lo que está.
#
# Además, al estimar se excluye la franja que se está evaluando: si no, la
# franja que mejor ventila define la referencia con su propio valor final,
# resulta Ct <= Cext y se queda sin ACH — justo la mejor del día.
#
# $franjaExcluir = nombre de la franja a excluir del mínimo, o $null.
function ReferenciaExterior($espacio, $filasCO2, $franjas, $co2Exterior, $franjaExcluir) {
    if ($co2Exterior.ContainsKey($espacio)) {
        return @{ valor = $co2Exterior[$espacio]; medida = $true; origen = "medida al aire libre" }
    }
    $mins = @()
    foreach ($fr in ($franjas | Where-Object { $_.vacio })) {
        if ($franjaExcluir -ne $null -and $fr.nombre -eq $franjaExcluir) { continue }
        $ff = $filasCO2 | Where-Object { $_.segundos -ge ($fr.ini*60) -and $_.segundos -lt ($fr.fin*60) }
        if ($ff.Count -gt 0) { $mins += (($ff | Measure-Object -Property co2 -Minimum).Minimum) }
    }
    if ($mins.Count -gt 0) {
        return @{ valor = ($mins | Measure-Object -Minimum).Minimum; medida = $false
                  origen = "mínimo de las otras franjas sin ocupación" }
    }
    # Sin otras franjas vacías: se recurre al mínimo del día completo.
    if ($filasCO2.Count -eq 0) { return $null }
    return @{ valor = ($filasCO2 | Measure-Object -Property co2 -Minimum).Minimum; medida = $false
              origen = "mínimo interior del día" }
}

# ── Graduación por variable para la síntesis diaria ──
# Temperatura y humedad se gradúan por el tiempo que pasan fuera de rango.
# El aire prioriza la renovación (ACH) sobre el nivel puntual, porque es un
# dato estructural del espacio y no del momento.

function GradoRango($vals, $optMin, $optMax, $legMin, $legMax, $riesgo) {
    if ($vals.Count -eq 0) { return 0 }
    $n = $vals.Count
    $fueraLegal = ($vals | Where-Object { $_ -lt $legMin -or $_ -gt $legMax }).Count
    $enOptimo   = ($vals | Where-Object { $_ -ge $optMin -and $_ -le $optMax }).Count
    $enRiesgo   = 0
    if ($riesgo -ne $null) { $enRiesgo = ($vals | Where-Object { $_ -ge $riesgo }).Count }
    $pctFuera  = Pct $fueraLegal $n
    $pctOptimo = Pct $enOptimo $n
    if ($enRiesgo -gt 0)      { return 5 }
    if ($pctFuera -gt 20)     { return 5 }
    if ($pctFuera -gt 0)      { return 4 }
    if ($pctOptimo -ge 80)    { return 1 }
    if ($pctOptimo -ge 40)    { return 2 }
    return 3
}

function GradoAire($ach, $pctSuperado) {
    # Si se pudo medir la renovación, manda ella: es la causa, no el síntoma.
    if ($ach -ne $null) {
        if ($ach -lt 3)      { return 5 }
        elseif ($ach -lt 4)  { return 4 }
        elseif ($ach -lt 5)  { return 3 }
        elseif ($ach -lt 6)  { return 2 }
        else                 { return 1 }
    }
    # Si no, por el tiempo que se supera el criterio diferencial del RITE
    if ($pctSuperado -eq $null) { return 0 }
    if ($pctSuperado -gt 50)  { return 5 }
    if ($pctSuperado -gt 25)  { return 4 }
    if ($pctSuperado -gt 10)  { return 3 }
    if ($pctSuperado -gt 0)   { return 2 }
    return 1
}

# ── Incertidumbre declarada de cada sensor, para propagarla hasta la letra ──
# revision-rigor-3.md, hallazgo 24: el proyecto acotaba con banda el ACH y el
# reparto exógeno/endógeno, y después comparaba esas cifras contra umbrales
# como si fueran exactas. Estas constantes cierran ese hueco: cada eje informa
# del grado y del RANGO DE GRADOS compatible con su incertidumbre.
$U_TEMP = 0.2    # SHT41, +/-0,2 C
$U_HUM  = 1.8    # SHT41, +/-1,8 % HR
$U_DB   = 2.0    # PCB Artists, +/-2 dB

# Grado de una variable de rango (T, HR) con su banda: se reevalúa desplazando
# todas las lecturas +/- la incertidumbre del sensor. No es monótono (bajar la
# temperatura puede empeorar el grado por el mínimo legal), de ahí el min/max.
function GradoRangoBanda($vals, $optMin, $optMax, $legMin, $legMax, $riesgo, $u) {
    if ($vals.Count -eq 0) { return @{ g = 0; lo = 0; hi = 0 } }
    $g  = GradoRango $vals $optMin $optMax $legMin $legMax $riesgo
    $gA = GradoRango ($vals | ForEach-Object { $_ - $u }) $optMin $optMax $legMin $legMax $riesgo
    $gB = GradoRango ($vals | ForEach-Object { $_ + $u }) $optMin $optMax $legMin $legMax $riesgo
    return @{ g = $g
              lo = [math]::Min([math]::Min($gA,$gB), $g)
              hi = [math]::Max([math]::Max($gA,$gB), $g) }
}

function PalabraGrado($g) {
    switch ($g) {
        1 { return "óptimo" }
        2 { return "aceptable" }
        3 { return "mejorable" }
        4 { return "deficiente" }
        5 { return "inadecuado" }
        default { return "sin datos" }
    }
}

function Letra($g) {
    switch ($g) {
        1 { return "A" }
        2 { return "B" }
        3 { return "C" }
        4 { return "D" }
        5 { return "E" }
        default { return "-" }
    }
}

# ── Criterios estructurales del aula vacía (RT, STI, fondo) ──
# Marco normativo (REVISION_RIGOR.md, hallazgo 2):
#   RT (reverberación)  CTE DB-HR (España), criterio PRINCIPAL. T <= 0,7 s
#                        con el aula vacía y mobiliario móvil, V <= 350 m3
#                        (supuesto declarado — documento de proyecto, 7.1).
#                        Solo exigible en obra nueva o rehabilitación con
#                        licencia posterior al RD 1371/2007: en edificios
#                        anteriores no lo es, y un resultado por encima se
#                        expresa como que el aula "se aleja de los valores
#                        que exigiría un edificio de nueva construcción",
#                        nunca como incumplimiento normativo.
#   STI (inteligibilidad) España no fija umbral para aulas. Se usa DIN 18041
#                        (>= 0,65, salas de comunicación) como referencia
#                        internacional de buena práctica, no como norma
#                        aplicable.
#   Fondo (aula vacía)  El CTE no fija un nivel de fondo. Se usa ANSI/ASA
#                        S12.60 (35 dBA) como referencia internacional,
#                        coincidente con la recomendación de la OMS ya
#                        recogida en umbrales.txt (DB_OPTIMO).
$RT_CTE_MAX  = 0.7   # CTE DB-HR, aula con mobiliario móvil, V<=350 m3
$STI_DIN_MIN = 0.65  # DIN 18041, salas de comunicación (referencia internacional)

# Grado estructural del espacio (Eje 1: el edificio, con el aula vacía).
# $u trae los tramos de fondo (DB_OPTIMO/ACEPTABLE/NORMAL/RIESGO) para no
# duplicar umbrales ya editables en umbrales.txt. El grado global es el
# peor de los ejes disponibles: la calidad estructural la marca el punto
# más débil, no una media que lo disimularía.
function Grado-Estructural($fondo, $rt, $sti, $u) {
    $gFondo = 3
    if ($fondo -lt $u.DB_OPTIMO)        { $gFondo = 1 }
    elseif ($fondo -lt $u.DB_ACEPTABLE) { $gFondo = 2 }
    elseif ($fondo -lt $u.DB_NORMAL)    { $gFondo = 3 }
    elseif ($fondo -lt $u.DB_RIESGO)    { $gFondo = 4 }
    else                                 { $gFondo = 5 }

    $gReverb = $null
    if ($rt -ne $null -and $rt -gt 0) {
        if ($rt -le 0.5)             { $gReverb = 1 }
        elseif ($rt -le $RT_CTE_MAX) { $gReverb = 2 }
        elseif ($rt -le 0.9)         { $gReverb = 3 }
        elseif ($rt -le 1.2)         { $gReverb = 4 }
        else                          { $gReverb = 5 }
    }

    $gSti = $null
    if ($sti -ne $null -and $sti -gt 0) {
        if ($sti -ge 0.75)             { $gSti = 1 }
        elseif ($sti -ge $STI_DIN_MIN) { $gSti = 2 }
        elseif ($sti -ge 0.60)         { $gSti = 3 }
        elseif ($sti -ge 0.45)         { $gSti = 4 }
        else                            { $gSti = 5 }
    }

    $disponibles = @($gFondo, $gReverb, $gSti) | Where-Object { $_ -ne $null }
    $gGlobal = ($disponibles | Measure-Object -Maximum).Maximum

    return @{ fondo = $gFondo; reverb = $gReverb; sti = $gSti; global = $gGlobal }
}

# ── Eje 2: condiciones acústicas EN ACTIVIDAD ──────────────────────────
# Rediseñado en la tercera revisión (hallazgo 24). Antes esto devolvía tres
# categorías y un modificador de "fluctuación alta" que se disparaba con un
# índice cuyo umbral equivalía a 2,2 dB de diferencia entre el LAeq y el fondo:
# lo cumplía hasta una biblioteca a 34 dB, de modo que la categoría FAVORABLE
# era inalcanzable y, con ella, las notas A y B de la jornada.
#
# Ahora el eje se gradúa por el NIVEL, con los mismos tramos DB_* de
# umbrales.txt que ya usa el eje estructural, y la FLUCTUACIÓN se informa como
# perfil descriptivo sin tocar la letra. La razón es de método: los tramos de
# nivel tienen un efecto declarado por tramo (documento de proyecto, 7.1:
# "aula ocupada en silencio", "actividad docente habitual", "esfuerzo vocal del
# docente", "comunicación comprometida"), mientras que para la fluctuación no
# existe escala ninguna. Inventar un umbral para mover una letra fue justo el
# error del hallazgo 24; describir la fluctuación con sus cifras conserva el
# hallazgo de BREATHE sin fingir un criterio que no hay.
#
# ATENCIÓN: estos tramos NO son normativos. No existe norma que fije el nivel
# aceptable de un aula ocupada. Son el criterio propio del proyecto, declarado
# como tal en el informe y en el documento de proyecto.
function GradoNivelDb($laeq, $u) {
    if ($laeq -eq $null) { return 0 }
    if ($laeq -lt $u.DB_OPTIMO)        { return 1 }
    elseif ($laeq -lt $u.DB_ACEPTABLE) { return 2 }
    elseif ($laeq -lt $u.DB_NORMAL)    { return 3 }
    elseif ($laeq -lt $u.DB_RIESGO)    { return 4 }
    else                               { return 5 }
}

# Perfil de fluctuación. Descriptivo: no entra en ninguna letra.
# El corte de 12 dB de rango dinámico es un CRITERIO PROPIO, no normativo. Se
# sitúa entre los dos arquetipos que documenta el proyecto -- el zumbido
# constante (rango de pocos dB) y el aula interrumpida (rango de treinta y
# tantos) -- y debe recalibrarse cuando haya medidas de campo suficientes.
$RANGO_FLUCTUA = 12
function PerfilFluctuacion($rango, $evHora, $laeq, $u) {
    if ($rango -eq $null) { return $null }
    if ($rango -ge $RANGO_FLUCTUA) {
        return "ambiente con interrupciones frecuentes"
    }
    if ($laeq -ne $null -and $laeq -ge $u.DB_NORMAL) {
        return "ruido SOSTENIDO, sin interrupciones: revisar instalaciones (clima, ventiladores, zumbidos)"
    }
    return "ambiente tranquilo y estable"
}

# Resumen compacto de un conjunto de filas (una franja o un día)
function Resumen-Bloque($filas, $u, $inf, $sangria) {
    $s = $sangria
    $n = $filas.Count
    if ($n -eq 0) { return }

    $vT = ($filas | Where-Object { $_.estado -notlike "*ERR_TH*" }).temp
    $vC = ($filas | Where-Object { $_.estado -notlike "*ERR_CO2*" -and $_.co2 -gt 0 }).co2
    $vD = $filas | Where-Object { $_.estado -notlike "*ERR_DB*" -and $_.estado -notlike "*DB_MUESTRA_UNICA*" -and $_.estado -notlike "*DB_INCOMPLETO*" -and $_.laeq -gt 0 }

    $st = Stats $vT; $sc = Stats $vC
    $laeq = LaeqGlobal $filas

    $lin = "$s"
    if ($st)   { $lin += ("T {0,4:N1}-{1,4:N1} C" -f $st.min, $st.max) } else { $lin += "T    n/d      " }
    if ($sc)   { $lin += ("  CO2 {0,4:N0}-{1,4:N0} ppm" -f $sc.min, $sc.max) } else { $lin += "  CO2   n/d     " }
    if ($laeq -ne $null) { $lin += ("  LAeq {0,4:N1} dB" -f $laeq) }
    $inf.Add($lin) | Out-Null

    # Detalles solo si hay algo destacable
    $avisos = @()
    if ($st -and $st.max -gt $u.T_MAX_LEGAL) {
        $k = ($vT | Where-Object { $_ -gt $u.T_MAX_LEGAL }).Count
        $avisos += ("temperatura sobre el máximo legal el {0:N0} % del tiempo" -f (Pct $k $st.n))
    }
    if ($sc -and $sc.max -ge $u.CO2_DEFICIENTE) {
        $k = ($vC | Where-Object { $_ -ge $u.CO2_DEFICIENTE }).Count
        $avisos += ("CO2 en mala calidad el {0:N0} % del tiempo" -f (Pct $k $sc.n))
    }
    if ($vD.Count -gt 0) {
        $rangos = $vD | ForEach-Object { $_.maxF - $_.fondo }
        $sr = Stats $rangos
        $ev = ($vD | Measure-Object -Property eventos -Sum).Sum
        # Fondo promediado ENERGÉTICAMENTE, no en decibelios: la media
        # aritmética de dB queda por debajo de la energética y la diferencia
        # crece con la dispersión (revision-rigor-3.md, hallazgo 30).
        $eF = 0.0; foreach ($f in $vD) { $eF += [math]::Pow(10, $f.fondo/10.0) }
        $fondoE = 10*[math]::Log10($eF/$vD.Count)
        $avisos += ("fondo {0:N0} dB, rango dinámico {1:N0} dB, {2} eventos" -f $fondoE, $sr.avg, $ev)
    }
    foreach ($a in $avisos) { $inf.Add("$s   - $a") | Out-Null }
}

# ── Referencia de ruido exterior: perfil del sábado (REVISION_RIGOR.md, hallazgo 5) ──
# El sábado el centro está cerrado: sin actividad escolar en pasillos, patio
# ni aulas contiguas, y con las ventanas de esa aula cerradas por defecto (el
# equipo no lo mide; es un supuesto que debe declararse y, si se dispone de
# ello, contrastarse con una anotación N). Es una referencia mejor que una
# franja vacía del mismo día lectivo porque:
#   - aísla el ruido exterior de cualquier actividad propia del centro
#     (hallazgo 5, punto 3: pasillos y aulas contiguas ya no contaminan);
#   - se puede comparar en la MISMA franja horaria que la clase que se quiere
#     valorar, en vez de con la franja vacía más próxima del propio día
#     (hallazgo 5, punto 2: el tráfico varía a lo largo del día).
# Sigue siendo una ESTIMACIÓN con un supuesto declarado, no una medición: que
# el tráfico de un sábado a esa hora sea representativo del de un día lectivo
# a la misma hora. `PerfilReferenciaSabado` no lo demuestra, solo lo aplica;
# el aviso de fiabilidad se imprime junto al resultado (ver "ORIGEN DEL
# RUIDO" en Get-Análisis) y se contrasta, cuando hay datos, contra las
# franjas vacías del propio día lectivo.
function PerfilReferenciaSabado($fEsp, $franjas) {
    $porDia = $fEsp.dia | Select-Object -Unique
    $sabados = @()
    foreach ($d in $porDia) {
        try {
            $fecha = [datetime]::ParseExact($d, "yyyy-MM-dd", $null)
            if ([int]$fecha.DayOfWeek -eq 6) { $sabados += $d }
        } catch { }
    }
    $perfil = @{}
    if ($sabados.Count -eq 0) { return @{ perfil = $perfil; dias = $sabados } }

    $fSab = $fEsp | Where-Object { $sabados -contains $_.dia }
    foreach ($fr in $franjas) {
        $fF = $fSab | Where-Object { $_.segundos -ge ($fr.ini*60) -and $_.segundos -lt ($fr.fin*60) -and $_.estado -notlike "*ERR_DB*" -and $_.estado -notlike "*DB_MUESTRA_UNICA*" -and $_.estado -notlike "*DB_INCOMPLETO*" -and $_.laeq -gt 0 }
        if ($fF.Count -eq 0) { continue }
        $lq = LaeqGlobal $fF
        $sf = Stats ($fF.fondo)
        $perfil[$fr.nombre] = @{ laeq = $lq; fondo = $sf.avg; n = $fF.Count }
    }
    return @{ perfil = $perfil; dias = $sabados }
}

function Get-Análisis {
    param([System.Collections.Generic.List[string]]$lineas, $u, $franjas)

    $inf = New-Object System.Collections.Generic.List[string]
    if ($lineas.Count -lt 2) { $inf.Add("Sin registros que analizar.") | Out-Null; return $inf }

    # ── Parsear: filas de datos y marcas ──
    $filas = @()
    $notas = @()
    $ventanas = @()      # marcas #VENTANA (hallazgo 22)
    $sinFecha = @()     # filas con marca de tiempo no válida (hallazgo 26)
    $calibraciones = @() # marcas #CALIBRACION del comando C
    $espacio = "sin identificar"
    $exposicion = ""
    $exposiciones = @{}
    $reverberacion = @{}
    $inteligibilidad = @{}
    $co2Exterior = @{}      # CO2 exterior medido, por espacio (hallazgo 14)
    foreach ($l in $lineas) {
        if ($l.StartsWith("#ESPACIO,")) {
            $p = $l.Split(",")
            if ($p.Count -ge 3) {
                # Formato: "Aula 3B / calle / RT 0.85 / STI 0.62"
                # El nombre es el primer campo; el resto son opcionales y su
                # orden es indiferente. Si el comando se repite para el mismo
                # espacio, los datos se FUSIONAN: permite anotar la
                # reverberacion mas tarde, cuando se haya medido.
                $campos = ($p[2..($p.Count-1)] -join ",").Split("/")
                $espacio = $campos[0].Trim()
                for ($k = 1; $k -lt $campos.Count; $k++) {
                    $c = $campos[$k].Trim()
                    if ($c -match "^(?i)sti\s*[:=]?\s*([\d.,]+)") {
                        $inteligibilidad[$espacio] = [double]($Matches[1] -replace ",", ".")
                    }
                    elseif ($c -match "^(?i)rt\s*[:=]?\s*([\d.,]+)") {
                        $reverberacion[$espacio] = [double]($Matches[1] -replace ",", ".")
                    }
                    elseif ($c -match "^(?i)cext\s*[:=]?\s*(\d+)") {
                        # CO2 exterior MEDIDO al aire libre junto al aula
                        # (revision-rigor-2.md, hallazgo 14). Sin este dato el
                        # análisis lo estima con el mínimo interior, que está
                        # sistemáticamente por encima del exterior real y
                        # sobrestima la ventilación.
                        $co2Exterior[$espacio] = [int]$Matches[1]
                    }
                    elseif ($c -match "(?i)^(calle|patio|interior|mixta)") {
                        $exposiciones[$espacio] = $Matches[1].ToLower()
                    }
                }
                if (-not $exposiciones.ContainsKey($espacio)) { $exposiciones[$espacio] = "" }
            }
            continue
        }
        if ($l.StartsWith("#VENTANA,")) {
            # El firmware escribe esta marca al cambiar la ventana horaria con
            # el comando W (revision-rigor-2.md, hallazgo 22).
            $p = $l.Split(",")
            if ($p.Count -ge 3) { $ventanas += [PSCustomObject]@{ ts=$p[1]; valor=$p[2].Trim() } }
            continue
        }
        if ($l.StartsWith("#CALIBRACION,")) {
            # El firmware escribe esta marca cuando se ejecuta C CALIBRAR. Una
            # calibración de fondo desplaza la línea base del sensor, así que
            # las lecturas de CO2 anteriores y posteriores NO son comparables:
            # el informe tiene que avisarlo, porque un salto de decenas de ppm
            # en mitad de una campaña se leería como un cambio de ventilación.
            $p = $l.Split(",")
            if ($p.Count -ge 3) {
                $calibraciones += [PSCustomObject]@{
                    ts=$p[1]; espacio=$espacio; texto=(($p[2..($p.Count-1)] -join ",").Trim()) }
            }
            continue
        }
        if ($l.StartsWith("#NOTA,")) {
            $p = $l.Split(",")
            if ($p.Count -ge 3) { $notas += [PSCustomObject]@{ ts=$p[1]; espacio=$espacio; texto=($p[2..($p.Count-1)] -join ",") } }
            continue
        }
        if ($l.StartsWith("timestamp")) { continue }
        $c = $l.Split(",")
        # Formato del CSV: 9 columnas.
        #   timestamp,temp_C,hum_pct,co2_ppm,dB_LAeq,dB_fondo,dB_maxF,eventos,estado
        # Hasta la tercera revisión el parser admitía también un formato de 10
        # columnas con un campo dB_max (pico crudo de 31 ms) que produjo una
        # versión del firmware anterior a la corrección de los hallazgos
        # 12/13/15. Esa versión nunca se publicó, de modo que no existe ni puede
        # existir ningún fichero en ese formato: la compatibilidad se eliminó
        # con su bandera, su campo duplicado y su aviso (simplificación S1).
        if ($c.Count -lt 9) { continue }
        # Fecha válida: sin ella la fila no puede atribuirse a ninguna jornada.
        # El firmware escribe 0000-00-00T00:00:00 cuando el reloj falla, y esas
        # filas formaban una "jornada" completa, con síntesis y nota
        # (revision-rigor-3.md, hallazgo 26). Se apartan aquí.
        $tsOk = ($c[0] -match "^(\d{4})-(\d{2})-(\d{2})T\d{2}:\d{2}:\d{2}$") -and
                ([int]$Matches[1] -ge 2020) -and ([int]$Matches[2] -ge 1) -and ([int]$Matches[2] -le 12) -and
                ([int]$Matches[3] -ge 1) -and ([int]$Matches[3] -le 31)
        try {
            $fila = [PSCustomObject]@{
                espacio = $espacio
                ts      = $c[0]
                dia     = $c[0].Substring(0,10)
                # Un solo campo de tiempo: segundos desde medianoche
                # (simplificación S3). Antes convivían "minutos" y "segundos",
                # la misma magnitud en dos unidades, y nada impedía que un
                # cálculo usara la de menor resolución, que es exactamente el
                # error del hallazgo 19 de la segunda revisión.
                segundos = $(if ($tsOk) { [int]$c[0].Substring(11,2)*3600 + [int]$c[0].Substring(14,2)*60 + [int]$c[0].Substring(17,2) } else { 0 })
                temp    = [double]($c[1] -replace ",", ".")
                hum     = [double]($c[2] -replace ",", ".")
                co2     = [int]$c[3]
                laeq    = [double]($c[4] -replace ",", ".")   # con decimal (hallazgo 18)
                fondo   = [int]$c[5]
                maxF    = [int]$c[6]
                eventos = [int]$c[7]
                estado  = $c[8]
            }
            if ($tsOk) { $filas += $fila } else { $sinFecha += $fila }
        } catch { }
    }
    if ($filas.Count -eq 0) { $inf.Add("No se pudo interpretar ningún registro.") | Out-Null; return $inf }

    $inf.Add("====================================================================") | Out-Null
    $inf.Add("  ANÁLISIS DEL REGISTRO") | Out-Null
    $inf.Add("====================================================================") | Out-Null
    $inf.Add("") | Out-Null
    $inf.Add("  AVISO: este equipo NO es un instrumento de medida homologado ni") | Out-Null
    $inf.Add("  sometido a verificación metrológica periódica. Los valores de este") | Out-Null
    $inf.Add("  informe son ORIENTATIVOS: sirven para detectar problemas y decidir") | Out-Null
    $inf.Add("  si conviene una medición formal con instrumentación certificada,") | Out-Null
    $inf.Add("  pero no tienen validez legal ni sirven como prueba en un") | Out-Null
    $inf.Add("  procedimiento administrativo o judicial. Ver REVISION_RIGOR.md,") | Out-Null
    $inf.Add("  hallazgo 10.") | Out-Null
    $inf.Add("") | Out-Null

    # Intervalo de registro: MEDIANA de las diferencias entre filas
    # consecutivas del mismo día. Antes se deducía de la distancia entre la
    # segunda y la tercera fila del fichero, de modo que un reinicio de cinco
    # minutos justo ahí -- tres filas de mil quinientas -- daba 300 s en vez de
    # 30 y dividía por diez los eventos por hora, que además es el indicador
    # que decide la valoración acústica (revision-rigor-3.md, hallazgo 28).
    # La mediana es robusta por construcción: da igual cuántos huecos haya
    # mientras sean minoría.
    $intervaloSeg = 30
    $difs = @()
    for ($i = 1; $i -lt $filas.Count; $i++) {
        if ($filas[$i].dia -ne $filas[$i-1].dia) { continue }
        $d = $filas[$i].segundos - $filas[$i-1].segundos
        if ($d -gt 0 -and $d -lt 600) { $difs += $d }
    }
    if ($difs.Count -ge 3) {
        $ord = $difs | Sort-Object
        $intervaloSeg = $ord[[int][math]::Floor($ord.Count/2)]
    }

    $inf.Add(("  Registros: {0}   (intervalo {1:N0} s)" -f $filas.Count, $intervaloSeg)) | Out-Null

    $espacios = $filas.espacio | Select-Object -Unique
    $inf.Add(("  Espacios:  {0}" -f ($espacios -join ", "))) | Out-Null
    if ($espacios -contains "sin identificar") {
        $inf.Add("  AVISO: hay registros sin identificar. Usa el comando E al") | Out-Null
        $inf.Add("         instalar el equipo para saber a que aula pertenecen.") | Out-Null
    }
    $sinExpo = $espacios | Where-Object { [string]::IsNullOrEmpty($exposiciones[$_]) }
    if ($sinExpo.Count -gt 0) {
        $inf.Add(("  AVISO: sin exposición indicada en: {0}" -f ($sinExpo -join ", "))) | Out-Null
        $inf.Add("         Indícala al identificar el espacio:  E Aula 3B / calle") | Out-Null
        $inf.Add("         Sin ella no puede interpretarse el ruido exterior.") | Out-Null
    }
    $inf.Add("") | Out-Null

    # ── Recorrido por espacio y día ──
    foreach ($esp in $espacios) {
        $fEsp = $filas | Where-Object { $_.espacio -eq $esp }
        $refSabado = PerfilReferenciaSabado $fEsp $franjas
        $inf.Add("====================================================================") | Out-Null
        $expo = $exposiciones[$esp]
        if ([string]::IsNullOrEmpty($expo)) { $expo = "sin especificar" }
        $inf.Add(("  ESPACIO: {0}    ({1} registros)" -f $esp, $fEsp.Count)) | Out-Null
        $inf.Add(("  Exposición: {0}" -f $expo)) | Out-Null
        $inf.Add("====================================================================") | Out-Null

        $dias = $fEsp.dia | Select-Object -Unique | Sort-Object
        foreach ($d in $dias) {
            $fDia = $fEsp | Where-Object { $_.dia -eq $d }

            # En fin de semana no hay actividad escolar: TODO lo registrado es
            # ruido exterior. Es la referencia mas limpia del fondo estructural,
            # sin contaminación de pasillos, patio ni aulas contiguas.
            $esFinDeSemana = $false
            $nombreDia = ""
            try {
                $fecha = [datetime]::ParseExact($d, "yyyy-MM-dd", $null)
                $dow = [int]$fecha.DayOfWeek
                $esFinDeSemana = ($dow -eq 0 -or $dow -eq 6)
                $nombreDia = @("domingo","lunes","martes","miércoles","jueves","viernes","sábado")[$dow]
            } catch { }

            $inf.Add("") | Out-Null
            if ($esFinDeSemana) {
                $inf.Add(("  --- {0} ({1})   {2} registros   SIN ACTIVIDAD ESCOLAR ---" -f $d, $nombreDia, $fDia.Count)) | Out-Null
            } else {
                $inf.Add(("  --- {0} ({1})   {2} registros ---" -f $d, $nombreDia, $fDia.Count)) | Out-Null
            }

            # Ventana horaria vigente ese día. El firmware deja una marca
            # #VENTANA cada vez que cambia, incluida la extensión automática de
            # la primera jornada en cada aula (revision-rigor-3.md, hallazgo 35).
            # Hasta ahora esas marcas se leían y no se usaban (hallazgo 33).
            $vDia = $ventanas | Where-Object { $_.ts.StartsWith($d) }
            foreach ($vv in $vDia) {
                if ($vv.valor -like "*auto*" -and $vv.valor -notlike "*fin*") {
                    $inf.Add("      Primera jornada en el aula: registro ampliado a 24 h (automático).") | Out-Null
                    $inf.Add("      Es la noche con ocupación nula que exige el cálculo de renovación.") | Out-Null
                } elseif ($vv.valor -like "*fin auto*") {
                    $inf.Add(("      {0}  fin del registro de 24 h; vuelve al horario configurado." -f $vv.ts.Substring(11,5))) | Out-Null
                } else {
                    $inf.Add(("      {0}  ventana horaria cambiada a {1}" -f $vv.ts.Substring(11,5), $vv.valor)) | Out-Null
                }
            }

            # ══ SÍNTESIS DE LA JORNADA ══
            # Va al principio para que quien solo quiera la conclusión la tenga
            # arriba, y quien quiera el porqué siga leyendo. Los cálculos se
            # repiten después con más detalle en sus bloques respectivos.
            if (-not $esFinDeSemana) {
                $vT2 = ($fDia | Where-Object { $_.estado -notlike "*ERR_TH*" }).temp
                $vH2 = ($fDia | Where-Object { $_.estado -notlike "*ERR_TH*" }).hum
                $fC2 = $fDia | Where-Object { $_.estado -notlike "*ERR_CO2*" -and $_.co2 -gt 0 }
                $fD2 = $fDia | Where-Object { $_.estado -notlike "*ERR_DB*" -and $_.estado -notlike "*DB_MUESTRA_UNICA*" -and $_.estado -notlike "*DB_INCOMPLETO*" -and $_.laeq -gt 0 }

                # Referencia exterior de CO2 y renovación de aire
                $cExt2 = $null; $achMedia = $null; $achLoMedia = $null; $achHiMedia = $null; $pctRite = $null
                $cExt2Medida = $false
                if ($fC2.Count -gt 0) {
                    # Referencia para el criterio RITE: sin excluir ninguna franja.
                    $ref2 = ReferenciaExterior $esp $fC2 $franjas $co2Exterior $null
                    if ($ref2 -ne $null) { $cExt2 = $ref2.valor; $cExt2Medida = $ref2.medida }

                    # ACH por regresión, con la referencia recalculada para cada
                    # franja excluyéndola a ella misma (hallazgos 14 y 16).
                    $acs = @(); $acsLo = @(); $acsHi = @()
                    foreach ($fr in ($franjas | Where-Object { $_.vacio })) {
                        $ff = $fC2 | Where-Object { $_.segundos -ge ($fr.ini*60) -and $_.segundos -lt ($fr.fin*60) }
                        if ($ff.Count -lt 5) { continue }
                        $refFr = ReferenciaExterior $esp $fC2 $franjas $co2Exterior $fr.nombre
                        if ($refFr -eq $null) { continue }
                        $rg = CalcularACHRegresion $ff $refFr.valor
                        if ($rg -ne $null -and $rg.ach -gt 0 -and $rg.ach -lt 30) {
                            $acs += $rg.ach
                            $acsLo += [math]::Min($rg.lo, $rg.achLoSist)
                            $acsHi += [math]::Max($rg.hi, $rg.achHiSist)
                        }
                    }
                    if ($acs.Count -gt 0) { $achMedia = ($acs | Measure-Object -Average).Average }
                    if ($acsLo.Count -gt 0) { $achLoMedia = ($acsLo | Measure-Object -Average).Average }
                    if ($acsHi.Count -gt 0) { $achHiMedia = ($acsHi | Measure-Object -Average).Average }

                    $fL2 = @()
                    foreach ($fr in ($franjas | Where-Object { -not $_.vacio })) {
                        $fL2 += $fC2 | Where-Object { $_.segundos -ge ($fr.ini*60) -and $_.segundos -lt ($fr.fin*60) }
                    }
                    if ($fL2.Count -gt 0 -and $cExt2 -ne $null) {
                        $pctRite = Pct ($fL2 | Where-Object { $_.co2 -gt ($cExt2+500) }).Count $fL2.Count
                    }
                }

                # ── Acústica de la actividad ──
                # El reparto exógeno/endógeno se calcula CON BANDA y con la
                # franja vacía más próxima en el tiempo, igual que en la
                # sección de detalle. Hasta la tercera revisión la síntesis
                # usaba una segunda vía: una cifra puntual sin banda y el
                # mínimo de todas las franjas vacías del día, y con ella
                # disparaba la recomendación de obra (hallazgo 25). Un 30 %
                # calculado así es compatible con cualquier valor entre el
                # 12 % y el 75 %: el umbral caía dentro de su propia banda.
                $lqAct2 = $null; $gRu = 0; $gRuLo = 0; $gRuHi = 0
                $perfilFl = $null; $repExt = $null; $raA2 = $null; $evA2 = $null
                $act2 = @()
                foreach ($fr in ($franjas | Where-Object { -not $_.vacio })) {
                    $act2 += $fD2 | Where-Object { $_.segundos -ge ($fr.ini*60) -and $_.segundos -lt ($fr.fin*60) }
                }
                if ($act2.Count -gt 0) {
                    $lqAct2 = LaeqGlobal $act2
                    $raA2 = (Stats ($act2 | ForEach-Object { $_.maxF - $_.fondo })).avg
                    $evA2 = ($act2 | Measure-Object -Property eventos -Sum).Sum / ($act2.Count * $intervaloSeg / 3600.0)
                    $gRu   = GradoNivelDb $lqAct2 $u
                    $gRuLo = GradoNivelDb ($lqAct2 - $U_DB) $u
                    $gRuHi = GradoNivelDb ($lqAct2 + $U_DB) $u
                    $perfilFl = PerfilFluctuacion $raA2 $evA2 $lqAct2 $u
                    # Referencia exterior: la franja vacía cuyo centro está más
                    # cerca del centro de la actividad. El ruido de tráfico de
                    # las 8:00 no es el de las 14:00.
                    $centroAct = (($act2 | Measure-Object -Property segundos -Average).Average) / 60.0
                    $cand = @()
                    foreach ($fr in ($franjas | Where-Object { $_.vacio })) {
                        $ff = $fD2 | Where-Object { $_.segundos -ge ($fr.ini*60) -and $_.segundos -lt ($fr.fin*60) }
                        if ($ff.Count -gt 0) {
                            $cand += [PSCustomObject]@{ laeq = (LaeqGlobal $ff)
                                                        centro = ($fr.ini + $fr.fin)/2.0 }
                        }
                    }
                    if ($cand.Count -gt 0) {
                        $ref = $cand | Sort-Object { [math]::Abs($_.centro - $centroAct) } | Select-Object -First 1
                        $repExt = RepartoConBanda $lqAct2 $ref.laeq $U_DB
                    }
                }

                # ── Grados de la jornada, cada uno con su banda ──
                # revision-rigor-3.md, hallazgos 24 y 27. Cada eje devuelve el
                # grado y el rango de grados compatible con la incertidumbre de
                # su sensor. La letra del día es el PEOR de los ejes con dato, y
                # el informe declara sobre cuántos ejes se ha calculado: no
                # medir una variable ya no mejora la nota en silencio.
                $bT = GradoRangoBanda $vT2 $u.T_OPTIMO_MIN $u.T_OPTIMO_MAX $u.T_MIN_LEGAL $u.T_MAX_LEGAL $u.T_RIESGO $U_TEMP
                $bH = GradoRangoBanda $vH2 $u.HR_OPTIMO_MIN $u.HR_OPTIMO_MAX $u.HR_MIN_LEGAL $u.HR_MAX_LEGAL $null $U_HUM
                $gT = $bT.g; $gH = $bH.g
                $gA = GradoAire $achMedia $pctRite
                $gALo = if ($achMedia -ne $null -and $achHiMedia -ne $null) { GradoAire $achHiMedia $pctRite } else { $gA }
                $gAHi = if ($achMedia -ne $null -and $achLoMedia -ne $null) { GradoAire $achLoMedia $pctRite } else { $gA }

                $ejes = @(
                    @{ n = "temperatura"; g = $gT;  lo = $bT.lo; hi = $bT.hi }
                    @{ n = "humedad";     g = $gH;  lo = $bH.lo; hi = $bH.hi }
                    @{ n = "ventilación"; g = $gA;  lo = [math]::Min($gALo,$gAHi); hi = [math]::Max($gALo,$gAHi) }
                    @{ n = "acústica";    g = $gRu; lo = $gRuLo; hi = $gRuHi }
                )
                $conDato = $ejes | Where-Object { $_.g -gt 0 }
                $sinDato = $ejes | Where-Object { $_.g -le 0 }
                $gDia   = if ($conDato.Count -gt 0) { ($conDato | ForEach-Object { $_.g }  | Measure-Object -Maximum).Maximum } else { 0 }
                $gDiaLo = if ($conDato.Count -gt 0) { ($conDato | ForEach-Object { $_.lo } | Measure-Object -Maximum).Maximum } else { 0 }
                $gDiaHi = if ($conDato.Count -gt 0) { ($conDato | ForEach-Object { $_.hi } | Measure-Object -Maximum).Maximum } else { 0 }

                $inf.Add("  +-- SÍNTESIS DE LA JORNADA -----------------------------------------+") | Out-Null
                $inf.Add("") | Out-Null

                # TEMPERATURA
                if ($vT2.Count -gt 0) {
                    $sT = Stats $vT2
                    $inf.Add(("    TEMPERATURA    {0,4:N1} - {1,4:N1} C                {2}    {3}" -f $sT.min, $sT.max, (Letra $gT), (PalabraGrado $gT))) | Out-Null
                    $pf = Pct ($vT2 | Where-Object { $_ -gt $u.T_MAX_LEGAL }).Count $vT2.Count
                    $deriva = $sT.max - $sT.min
                    $det = @()
                    if ($pf -gt 0) { $det += ("{0:N0} % del día sobre el máximo legal" -f $pf) }
                    if ($deriva -gt 5) { $det += ("deriva de {0:+0.0} C" -f $deriva) }
                    if ($det.Count -gt 0) { $inf.Add("       " + ($det -join "; ")) | Out-Null }
                    if ($gT -ge 4) { $inf.Add("       -> Protección solar y ventilación nocturna") | Out-Null }
                    elseif ($gT -le 2) { $inf.Add("       -> Sin actuación") | Out-Null }
                    $inf.Add("") | Out-Null
                }

                # HUMEDAD
                if ($vH2.Count -gt 0) {
                    $sH = Stats $vH2
                    $inf.Add(("    HUMEDAD        {0,4:N0} - {1,4:N0} %                 {2}    {3}" -f $sH.min, $sH.max, (Letra $gH), (PalabraGrado $gH))) | Out-Null
                    $pfH = Pct ($vH2 | Where-Object { $_ -lt $u.HR_MIN_LEGAL -or $_ -gt $u.HR_MAX_LEGAL }).Count $vH2.Count
                    if ($pfH -gt 0) { $inf.Add(("       {0:N0} % del día fuera del rango legal" -f $pfH)) | Out-Null }
                    else { $inf.Add("       Dentro del rango legal toda la jornada") | Out-Null }
                    if ($gH -ge 4) { $inf.Add("       -> Revisar ventilación y fuentes de humedad") | Out-Null }
                    else { $inf.Add("       -> Sin actuación") | Out-Null }
                    $inf.Add("") | Out-Null
                }

                # AIRE
                if ($fC2.Count -gt 0) {
                    $sC = Stats ($fC2.co2)
                    $inf.Add(("    AIRE (CO2)     {0,4:N0} - {1,4:N0} ppm               {2}    {3}" -f $sC.min, $sC.max, (Letra $gA), (PalabraGrado $gA))) | Out-Null
                    if ($achMedia -ne $null) {
                        if ($achLoMedia -ne $null -and $achHiMedia -ne $null) {
                            $inf.Add(("       {0:N1} renovaciones/hora (banda {1:N1}-{2:N1}) frente a las 4" -f $achMedia, $achLoMedia, $achHiMedia)) | Out-Null
                            $inf.Add(("       recomendadas  ->  {0}{1}" -f (ValorarACH $achMedia), $(if (-not $cExt2Medida) { "  (exterior estimado: el ACH real es probablemente menor)" } else { "" }))) | Out-Null
                        } else {
                            $inf.Add(("       {0:N1} renovaciones/hora frente a las 4 recomendadas  ->  {1}" -f $achMedia, (ValorarACH $achMedia))) | Out-Null
                            $inf.Add("       (banda de incertidumbre no acotable: caída de CO2 demasiado") | Out-Null
                            $inf.Add("       pequeña frente al exterior; cifra orientativa, ver detalle abajo)") | Out-Null
                        }
                        if ($achMedia -lt 3) { $inf.Add("       -> Capacidad de ventilación insuficiente: requiere intervención") | Out-Null }
                        elseif ($achMedia -lt 4) { $inf.Add("       -> Ventilación en el límite: reforzar apertura de ventanas") | Out-Null }
                        elseif ($pctRite -ne $null -and $pctRite -gt 25) { $inf.Add("       -> Ventilación suficiente mal aprovechada: revisar la pauta de apertura") | Out-Null }
                        else { $inf.Add("       -> Sin actuación") | Out-Null }
                    } elseif ($pctRite -ne $null) {
                        $inf.Add(("       Criterio RITE superado el {0:N0} % del tiempo de actividad" -f $pctRite)) | Out-Null
                        if ($pctRite -gt 25) { $inf.Add("       -> Revisar la pauta de ventilación") | Out-Null }
                        else { $inf.Add("       -> Sin actuación") | Out-Null }
                    }
                    $inf.Add("") | Out-Null
                }

                # RUIDO
                if ($lqAct2 -ne $null) {
                    $inf.Add(("    RUIDO          LAeq {0,4:N1} dB                {1}    {2}" -f $lqAct2, (Letra $gRu), (PalabraGrado $gRu))) | Out-Null
                    $inf.Add("       Criterio propio del proyecto, no normativo: no existe norma que") | Out-Null
                    $inf.Add("       fije el nivel aceptable de un aula ocupada (doc. de proyecto, 7.1).") | Out-Null
                    if ($perfilFl -ne $null) {
                        $inf.Add(("       Fluctuación: rango dinámico {0:N0} dB, {1:N0} eventos/h  ->  {2}" -f $raA2, $evA2, $perfilFl)) | Out-Null
                    }
                    # Origen del ruido: solo se afirma lo que la banda sostiene.
                    $lRep = TextoReparto "Origen del ruido" $repExt
                    if ($lRep -ne $null) { $inf.Add("       " + $lRep.TrimStart()) | Out-Null }
                    # Recomendación. La de obra (envolvente) solo se emite si la
                    # banda del reparto la sostiene: es la única del informe que
                    # cuesta dinero (revision-rigor-3.md, hallazgo 25).
                    # 0,7 s es el límite del CTE DB-HR para aula con mobiliario
                    # móvil ($RT_CTE_MAX): por encima, el problema es de
                    # absorción interior, no de aislamiento con el exterior.
                    $rtEsp = $reverberacion[$esp]
                    $extDominante = ($repExt -ne $null -and (
                        ($repExt.tipo -eq 'cifra'       -and $repExt.lo -ge 30) -or
                        ($repExt.tipo -eq 'cualitativo' -and $repExt.lo -gt 60)))
                    $extPosible = ($repExt -ne $null -and $repExt.tipo -ne 'nada' -and
                                   $repExt.hi -ge 30 -and -not $extDominante)
                    if ($extDominante) {
                        $inf.Add("       -> Actuar sobre la envolvente: ventanas y fachada") | Out-Null
                    } elseif ($gRu -ge 4 -and $rtEsp -ne $null -and $rtEsp -gt $RT_CTE_MAX) {
                        $inf.Add(("       -> Tratamiento absorbente (RT {0:N1} s), no aislamiento" -f $rtEsp)) | Out-Null
                    } elseif ($gRu -ge 4) {
                        $inf.Add("       -> Ruido de origen interno: dinámicas de aula y densidad") | Out-Null
                    } else {
                        $inf.Add("       -> Sin actuación por el nivel de ruido.") | Out-Null
                        if ($rtEsp -ne $null -and $rtEsp -gt $RT_CTE_MAX) {
                            $inf.Add(("          La reverberación (RT {0:N1} s) sí requiere tratamiento: es un" -f $rtEsp)) | Out-Null
                            $inf.Add("          defecto del espacio, no de esta jornada (ver valoración del espacio).") | Out-Null
                        }
                    }
                    # La banda no siempre permite decidir dónde actuar, y decirlo
                    # es parte del resultado (revision-rigor-3.md, hallazgo 25).
                    if ($extPosible) {
                        $inf.Add(("          El origen no queda separado: la banda admite hasta un {0:N0} %" -f $repExt.hi)) | Out-Null
                        $inf.Add("          exterior. Para decidir dónde actuar hace falta una referencia") | Out-Null
                        $inf.Add("          limpia: registra un sábado, o mide el RT.") | Out-Null
                    }
                    $inf.Add("") | Out-Null
                }

                # ── Valoración de la jornada ──
                # La letra es el peor eje CON DATO, y va acompañada de dos cosas
                # que antes faltaban: cuántos ejes la sostienen (hallazgo 27) y
                # si es firme frente a la incertidumbre de los sensores
                # (hallazgo 24). Un eje sin dato ya no mejora la nota en
                # silencio: se nombra.
                $inf.Add(("  +-- VALORACIÓN DE LA JORNADA:  {0} ---------------------------------+" -f (Letra $gDia))) | Out-Null
                $inf.Add(("     Calculada sobre {0} de 4 ejes." -f $conDato.Count)) | Out-Null
                if ($sinDato.Count -gt 0) {
                    $inf.Add(("     SIN DATO: {0}. La letra podría empeorar si se midieran." -f (($sinDato | ForEach-Object { $_.n }) -join ", "))) | Out-Null
                }
                if ($gDiaLo -ne $gDiaHi) {
                    $inf.Add(("     Con la incertidumbre de los sensores la nota está entre {0} y {1}:" -f (Letra $gDiaLo), (Letra $gDiaHi))) | Out-Null
                    $inf.Add("     alguna variable cae junto a un umbral. Léase la categoría, no la letra.") | Out-Null
                }
                # Factor o factores limitantes
                $lim = @()
                foreach ($e in $conDato) { if ($e.g -eq $gDia -and $gDia -ge 3) { $lim += ("la " + $e.n) } }
                if ($lim.Count -gt 0) {
                    $inf.Add(("     El factor limitante es {0}." -f ($lim -join " y "))) | Out-Null
                } elseif ($gDia -le 2 -and $conDato.Count -gt 0) {
                    $inf.Add(("     Condiciones adecuadas en {0} de las 4 variables{1}." -f $conDato.Count, $(if ($sinDato.Count -gt 0) { " medidas" } else { "" }))) | Out-Null
                }
                $inf.Add("") | Out-Null
            }

            # Resumen del día completo
            $inf.Add("  JORNADA COMPLETA:") | Out-Null
            Resumen-Bloque $fDia $u $inf "    "

            # ── FIN DE SEMANA: perfil de ruido exterior hora a hora ──
            if ($esFinDeSemana) {
                $inf.Add("  Sin ocupación: todo lo registrado es ruido EXTERIOR.") | Out-Null
                $inf.Add("  Es la referencia más limpia del ruido de fondo del espacio.") | Out-Null
                $inf.Add("") | Out-Null
                $inf.Add("  PERFIL HORARIO DE RUIDO EXTERIOR:") | Out-Null
                for ($h = 0; $h -lt 24; $h++) {
                    $fH = $fDia | Where-Object { $_.segundos -ge ($h*3600) -and $_.segundos -lt (($h+1)*3600) -and $_.estado -notlike "*ERR_DB*" -and $_.estado -notlike "*DB_MUESTRA_UNICA*" -and $_.estado -notlike "*DB_INCOMPLETO*" -and $_.laeq -gt 0 }
                    if ($fH.Count -eq 0) { continue }
                    $lqH = LaeqGlobal $fH
                    $sfH = Stats ($fH.fondo)
                    $smH = Stats ($fH.maxF)
                    $evH = ($fH | Measure-Object -Property eventos -Sum).Sum
                    $barra = "#" * [math]::Max(0, [math]::Min(30, [int](($lqH - 25) / 1.5)))
                    $inf.Add(("    {0:00}h  LAeq {1,4:N1}  fondo {2,4:N1}  pico {3,3:N0}  ev {4,3:N0}  {5}" -f $h, $lqH, $sfH.avg, $smH.max, $evH, $barra)) | Out-Null
                }
                # Franja más silenciosa: el fondo estructural real del aula
                $porHora = @()
                for ($h = 0; $h -lt 24; $h++) {
                    $fH = $fDia | Where-Object { $_.segundos -ge ($h*3600) -and $_.segundos -lt (($h+1)*3600) -and $_.estado -notlike "*ERR_DB*" -and $_.estado -notlike "*DB_MUESTRA_UNICA*" -and $_.estado -notlike "*DB_INCOMPLETO*" -and $_.laeq -gt 0 }
                    if ($fH.Count -gt 0) {
                        $porHora += [PSCustomObject]@{ h=$h; laeq=(LaeqGlobal $fH); fondo=(Stats ($fH.fondo)).avg }
                    }
                }
                if ($porHora.Count -gt 0) {
                    $mn = ($porHora | Sort-Object laeq)[0]
                    $mx = ($porHora | Sort-Object laeq -Descending)[0]
                    $inf.Add("") | Out-Null
                    $inf.Add(("    Hora más silenciosa: {0:00}h con LAeq {1:N1} dB y fondo {2:N1} dB" -f $mn.h, $mn.laeq, $mn.fondo)) | Out-Null
                    $inf.Add(("    Hora más ruidosa:    {0:00}h con LAeq {1:N1} dB" -f $mx.h, $mx.laeq)) | Out-Null
                    $inf.Add(("    Variación a lo largo del día: {0:N1} dB" -f ($mx.laeq - $mn.laeq))) | Out-Null
                    $inf.Add("    El fondo de la hora más silenciosa es el mejor estimador del") | Out-Null
                    $inf.Add("    ruido de fondo estructural del aula (aislamiento de la envolvente).") | Out-Null
                }
            }

            # Desglose por franjas (solo en días lectivos)
            if ($franjas.Count -gt 0 -and -not $esFinDeSemana) {
                $inf.Add("") | Out-Null
                $inf.Add("  POR FRANJAS:") | Out-Null
                foreach ($fr in $franjas) {
                    $fFr = $fDia | Where-Object { $_.segundos -ge ($fr.ini*60) -and $_.segundos -lt ($fr.fin*60) }
                    if ($fFr.Count -eq 0) { continue }
                    $inf.Add(("    [{0}]  {1} registros" -f $fr.nombre, $fFr.Count)) | Out-Null
                    Resumen-Bloque $fFr $u $inf "      "
                }
            }

            # ── Origen del ruido: exógeno vs endógeno (REVISION_RIGOR.md, hallazgo 5) ──
            # SIEMPRE una ESTIMACIÓN con supuestos declarados, nunca una medición:
            # solo una segunda unidad simultánea en el exterior lo sería (línea de
            # desarrollo futura, documento de proyecto, apdo. 8). Dos métodos, en
            # orden de preferencia:
            #   1) Referencia de SÁBADO (misma franja horaria, mismo espacio): el
            #      centro está cerrado, sin pasillos ni aulas contiguas activas, y
            #      se compara hora con hora en vez de con la franja vacía más
            #      próxima. Supuestos que quedan declarados en el informe: tráfico
            #      de sábado asimilable al de un día lectivo a esa hora, y ventanas
            #      cerradas durante la referencia (contrástalo con una anotación N
            #      si el sábado se dejaron abiertas).
            #   2) Franja vacía del propio día lectivo (método anterior), solo si
            #      no hay sábado disponible para este espacio. Sigue sujeto a las
            #      limitaciones originales: el tráfico puede variar a lo largo del
            #      día y las ventanas pueden no estar en el mismo estado ocupadas
            #      que vacías. No se usa en aulas orientadas a patio (la franja
            #      vacía ahí refleja actividad escolar exterior, no el exterior
            #      estructural).
            $frVacias = $franjas | Where-Object { $_.vacio }
            $expoEsp = $exposiciones[$esp]
            $perfil = @()
            if ($frVacias.Count -gt 0 -and -not $esFinDeSemana) {
                foreach ($fr in $frVacias) {
                    $fF = $fDia | Where-Object { $_.segundos -ge ($fr.ini*60) -and $_.segundos -lt ($fr.fin*60) -and $_.estado -notlike "*ERR_DB*" -and $_.estado -notlike "*DB_MUESTRA_UNICA*" -and $_.estado -notlike "*DB_INCOMPLETO*" -and $_.laeq -gt 0 }
                    if ($fF.Count -eq 0) { continue }
                    $lq = LaeqGlobal $fF
                    $sf = Stats ($fF.fondo)
                    $perfil += [PSCustomObject]@{
                        nombre = $fr.nombre; centro = ($fr.ini + $fr.fin)/2
                        laeq = $lq; fondo = $sf.avg; n = $fF.Count
                    }
                }
            }
            if ($perfil.Count -gt 0) {
                $inf.Add("") | Out-Null
                $inf.Add("  RUIDO EXTERIOR (franjas sin ocupación, este día):") | Out-Null
                foreach ($p in $perfil) {
                    $inf.Add(("    {0,-22} LAeq {1,4:N1} dB   fondo {2,4:N1} dB" -f $p.nombre, $p.laeq, $p.fondo)) | Out-Null
                }
                $vmin = ($perfil | Sort-Object laeq)[0]
                $vmax = ($perfil | Sort-Object laeq -Descending)[0]
                # 6 dB, por encima de la incertidumbre combinada del sonómetro
                # (±2 dB por lectura: REVISION_RIGOR.md, hallazgo 4) para no
                # afirmar una variación que el instrumento no puede sostener.
                if ($perfil.Count -gt 1 -and ($vmax.laeq - $vmin.laeq) -ge 6) {
                    $inf.Add(("    El ruido exterior varia {0:N0} dB entre franjas (por encima de la" -f ($vmax.laeq-$vmin.laeq))) | Out-Null
                    $inf.Add(("    incertidumbre del sensor): mínimo en {0}, máximo en {1}." -f $vmin.nombre, $vmax.nombre)) | Out-Null
                }
            }
            if (-not $esFinDeSemana) {
                if ($refSabado.perfil.Count -gt 0) {
                    # ── Método 1: referencia de sábado ──
                    $diasRef = ($refSabado.dias -join ", ")
                    $frOcup = $franjas | Where-Object { -not $_.vacio }
                    $lineasFuente = @()
                    $sinRef = @()
                    foreach ($fr in $frOcup) {
                        $fF = $fDia | Where-Object { $_.segundos -ge ($fr.ini*60) -and $_.segundos -lt ($fr.fin*60) -and $_.estado -notlike "*ERR_DB*" -and $_.estado -notlike "*DB_MUESTRA_UNICA*" -and $_.estado -notlike "*DB_INCOMPLETO*" -and $_.laeq -gt 0 }
                        if ($fF.Count -eq 0) { continue }
                        $lqTotal = LaeqGlobal $fF
                        $refFr = $refSabado.perfil[$fr.nombre]
                        if ($refFr -eq $null) { $sinRef += $fr.nombre; continue }
                        # Reparto con banda: la resta de dos niveles próximos
                        # amplifica la incertidumbre (hallazgo 18).
                        $rep = RepartoConBanda $lqTotal $refFr.laeq
                        $lineasFuente += (TextoReparto $fr.nombre $rep)
                    }
                    if ($lineasFuente.Count -gt 0) {
                        $inf.Add("") | Out-Null
                        $inf.Add(("  ORIGEN DEL RUIDO -- ESTIMACIÓN (referencia: sábado {0}, misma franja horaria):" -f $diasRef)) | Out-Null
                        foreach ($lf in $lineasFuente) { $inf.Add($lf) | Out-Null }
                        $inf.Add("    Un peso alto del exterior apunta a la envolvente del edificio;") | Out-Null
                        $inf.Add("    uno bajo, a la actividad y la acústica interior del aula.") | Out-Null
                        $inf.Add("    El porcentaje se da como BANDA: la resta de dos niveles próximos") | Out-Null
                        $inf.Add("    amplifica la incertidumbre de +/-2 dB del sonómetro, y una cifra") | Out-Null
                        $inf.Add("    exacta aparentaría una resolución que el dato no tiene.") | Out-Null
                        $inf.Add("    Supuestos: tráfico de sábado asimilable al de un día lectivo a la") | Out-Null
                        $inf.Add("    misma hora, y ventanas cerradas durante la referencia. Revisa las") | Out-Null
                        $inf.Add("    anotaciones (N) de ese sábado y de este día si mencionan ventanas.") | Out-Null

                        # Contraste de la premisa: si hay franjas vacías del propio día
                        # (mismo nombre) además de la referencia de sábado, se comparan.
                        # Una diferencia grande es un aviso de que el supuesto de tráfico
                        # similar puede no cumplirse esta semana en concreto.
                        $contraste = @()
                        foreach ($p in $perfil) {
                            $refFr = $refSabado.perfil[$p.nombre]
                            if ($refFr -ne $null) { $contraste += [PSCustomObject]@{ nombre=$p.nombre; dia=$p.laeq; sab=$refFr.laeq } }
                        }
                        if ($contraste.Count -gt 0) {
                            $inf.Add("") | Out-Null
                            $inf.Add("    Contraste con las franjas vacías de este día (mismo nombre):") | Out-Null
                            $avisoDivergencia = $false
                            foreach ($c in $contraste) {
                                $dif = $c.dia - $c.sab
                                $inf.Add(("      {0,-22} hoy {1,4:N1} dB   sábado {2,4:N1} dB   dif {3:+0.0;-0.0;0.0} dB" -f $c.nombre, $c.dia, $c.sab, $dif)) | Out-Null
                                if ([math]::Abs($dif) -ge 6) { $avisoDivergencia = $true }
                            }
                            if ($avisoDivergencia) {
                                $inf.Add("      [!] Diferencia por encima de la incertidumbre del sensor (±2 dB):") | Out-Null
                                $inf.Add("          el supuesto de tráfico similar puede no cumplirse esta semana;") | Out-Null
                                $inf.Add("          trata la estimación de origen con más cautela.") | Out-Null
                            }
                        }
                    }
                    if ($sinRef.Count -gt 0) {
                        $inf.Add("") | Out-Null
                        $inf.Add(("    Sin referencia de sábado para: {0} (esa franja no tuvo datos" -f ($sinRef -join ", "))) | Out-Null
                        $inf.Add("    válidos el sábado a esa hora).") | Out-Null
                    }
                } elseif ($perfil.Count -gt 0 -and $expoEsp -ne "patio") {
                    # ── Método 2 (respaldo): franja vacía más próxima del propio día ──
                    $frOcup = $franjas | Where-Object { -not $_.vacio }
                    $lineasFuente = @()
                    foreach ($fr in $frOcup) {
                        $fF = $fDia | Where-Object { $_.segundos -ge ($fr.ini*60) -and $_.segundos -lt ($fr.fin*60) -and $_.estado -notlike "*ERR_DB*" -and $_.estado -notlike "*DB_MUESTRA_UNICA*" -and $_.estado -notlike "*DB_INCOMPLETO*" -and $_.laeq -gt 0 }
                        if ($fF.Count -eq 0) { continue }
                        $lqTotal = LaeqGlobal $fF
                        $centroFr = ($fr.ini + $fr.fin)/2
                        $niveles = ($perfil.laeq | Sort-Object)
                        $mediana = $niveles[[int]($niveles.Count/2)]
                        $candidatas = $perfil | Where-Object { $_.laeq -le ($mediana + 6) }
                        if ($candidatas.Count -eq 0) { $candidatas = $perfil }
                        $ref = $candidatas | Sort-Object { [math]::Abs($_.centro - $centroFr) } | Select-Object -First 1
                        $rep = RepartoConBanda $lqTotal $ref.laeq
                        $lineasFuente += (TextoReparto $fr.nombre $rep)
                    }
                    if ($lineasFuente.Count -gt 0) {
                        $inf.Add("") | Out-Null
                        $inf.Add("  ORIGEN DEL RUIDO -- ESTIMACIÓN (sin sábado disponible; referencia:") | Out-Null
                        $inf.Add("  franja vacía más próxima de este mismo día, menos fiable):") | Out-Null
                        foreach ($lf in $lineasFuente) { $inf.Add($lf) | Out-Null }
                        $inf.Add("    Un peso alto del exterior apunta a la envolvente del edificio;") | Out-Null
                        $inf.Add("    uno bajo, a la actividad y la acústica interior del aula.") | Out-Null
                        $inf.Add("    El porcentaje se da como BANDA: la resta de dos niveles próximos") | Out-Null
                        $inf.Add("    amplifica la incertidumbre de +/-2 dB del sonómetro, y una cifra") | Out-Null
                        $inf.Add("    exacta aparentaría una resolución que el dato no tiene.") | Out-Null
                        $inf.Add("    Supuestos: el ruido exterior no cambia entre la franja vacía y la") | Out-Null
                        $inf.Add("    franja ocupada, y las ventanas están en el mismo estado en ambas.") | Out-Null
                        $inf.Add("    Ninguno de los dos está verificado. Revisa las anotaciones (N) de") | Out-Null
                        $inf.Add("    ese día por si mencionan ventanas. Si el equipo puede quedarse") | Out-Null
                        $inf.Add("    instalado hasta cubrir un sábado, la referencia de sábado es más") | Out-Null
                        $inf.Add("    fiable (ver arriba).") | Out-Null
                        $niveles = ($perfil.laeq | Sort-Object)
                        $mediana = $niveles[[int]($niveles.Count/2)]
                        $anom = $perfil | Where-Object { $_.laeq -gt ($mediana + 6) }
                        if ($anom.Count -gt 0) {
                            $inf.Add("") | Out-Null
                            foreach ($an in $anom) {
                                $inf.Add(("    NOTA: la franja «{0}» ({1:N1} dB) queda fuera de la referencia por" -f $an.nombre, $an.laeq)) | Out-Null
                                $inf.Add("          estar muy por encima de las demás franjas vacías. Refleja una") | Out-Null
                                $inf.Add("          fuente exterior puntual (p. ej. el patio), no el ruido habitual.") | Out-Null
                            }
                        }
                    }
                } elseif ($expoEsp -eq "patio") {
                    $inf.Add("") | Out-Null
                    $inf.Add("  ORIGEN DEL RUIDO: no se estima (sin referencia de sábado).") | Out-Null
                    $inf.Add("    El aula da al patio: las franjas sin ocupación de un día lectivo no") | Out-Null
                    $inf.Add("    reflejan el ruido exterior estructural sino la actividad escolar al") | Out-Null
                    $inf.Add("    aire libre (espera del comedor, educación física, recreos de otros") | Out-Null
                    $inf.Add("    grupos), así que no sirven de referencia. El sábado sí serviría (sin") | Out-Null
                    $inf.Add("    actividad escolar en el patio) pero no hay datos de sábado para esta") | Out-Null
                    $inf.Add("    aula. Los niveles de las franjas vacías siguen siendo válidos y están") | Out-Null
                    $inf.Add("    arriba: documentan un ruido exógeno real, pero no comparable con el") | Out-Null
                    $inf.Add("    marco de estudios sobre ruido de tráfico.") | Out-Null
                }
            }

            # ── CALIDAD DEL AIRE Y VENTILACIÓN ──
            if (-not $esFinDeSemana) {
                $fCO2 = $fDia | Where-Object { $_.estado -notlike "*ERR_CO2*" -and $_.co2 -gt 0 }
                if ($fCO2.Count -gt 0) {
                    # Referencia exterior de CO2 (revision-rigor-2.md, hallazgo 14).
                    # El RITE define IDA 2 como 500 ppm SOBRE el exterior, no como
                    # valor absoluto, así que esta referencia condiciona tanto el
                    # criterio normativo como el ACH.
                    $frV = $franjas | Where-Object { $_.vacio }
                    $refExt = ReferenciaExterior $esp $fCO2 $franjas $co2Exterior $null
                    if ($refExt -eq $null) { $cExt = $null } else { $cExt = $refExt.valor }

                    $inf.Add("") | Out-Null
                    $inf.Add("  CALIDAD DEL AIRE Y VENTILACIÓN") | Out-Null
                    if ($refExt.medida) {
                        $inf.Add(("    CO2 exterior MEDIDO: {0:N0} ppm  (anotado con E ... / CEXT)" -f $cExt)) | Out-Null
                    } else {
                        $inf.Add(("    CO2 exterior ESTIMADO: {0:N0} ppm  ({1})" -f $cExt, $refExt.origen)) | Out-Null
                        $inf.Add("      No es una medida exterior: es el valor más bajo observado DENTRO") | Out-Null
                        $inf.Add("      del aula. El interior casi nunca baja hasta el exterior real, así") | Out-Null
                        $inf.Add("      que esta referencia queda por encima del valor verdadero y el ACH") | Out-Null
                        $inf.Add("      sale ALTO: el sesgo va siempre en la dirección de hacer parecer el") | Out-Null
                        $inf.Add("      aula mejor ventilada de lo que está. Para eliminarlo, mide el CO2") | Out-Null
                        $inf.Add("      al aire libre junto al aula y anótalo:  E <espacio> / CEXT 420") | Out-Null
                    }

                    # Criterio diferencial del RITE
                    $umbralIDA2 = $cExt + 500
                    $fLect = $franjas | Where-Object { -not $_.vacio }
                    $filasLect = @()
                    foreach ($fr in $fLect) {
                        $filasLect += $fCO2 | Where-Object { $_.segundos -ge ($fr.ini*60) -and $_.segundos -lt ($fr.fin*60) }
                    }
                    if ($filasLect.Count -gt 0) {
                        $sup = ($filasLect | Where-Object { $_.co2 -gt $umbralIDA2 }).Count
                        $inf.Add(("    Criterio RITE IDA 2 ({0:N0} ppm sobre el exterior = {1:N0} ppm):" -f 500, $umbralIDA2)) | Out-Null
                        $inf.Add(("      superado el {0:N0} % del tiempo de actividad" -f (Pct $sup $filasLect.Count))) | Out-Null
                        $inf.Add("      El RITE fija el límite como diferencia con el aire exterior,") | Out-Null
                        $inf.Add("      no como valor absoluto.") | Out-Null
                        if (-not $refExt.medida) {
                            $inf.Add("      Aquí el 'exterior' es una ESTIMACIÓN desde dentro del aula, no") | Out-Null
                            $inf.Add("      una medida exterior simultánea: el umbral resultante queda alto") | Out-Null
                            $inf.Add("      y el porcentaje de tiempo superado, bajo. Anota CEXT para") | Out-Null
                            $inf.Add("      aplicar el criterio con una referencia real.") | Out-Null
                        }
                    }

                    # Renovación de aire por decaimiento del CO2, por REGRESIÓN
                    # log-lineal sobre todas las lecturas de la franja
                    # (revision-rigor-2.md, hallazgo 16). Para cada franja la
                    # referencia exterior se recalcula excluyéndola a ella misma,
                    # de modo que la franja mejor ventilada deje de autoexcluirse
                    # del cálculo (hallazgo 14).
                    $achs = @()
                    foreach ($fr in $frV) {
                        $ff = $fCO2 | Where-Object { $_.segundos -ge ($fr.ini*60) -and $_.segundos -lt ($fr.fin*60) }
                        if ($ff.Count -lt 5) { continue }
                        $refFr = ReferenciaExterior $esp $fCO2 $franjas $co2Exterior $fr.nombre
                        if ($refFr -eq $null) { continue }
                        $rg = CalcularACHRegresion $ff $refFr.valor
                        if ($rg -ne $null -and $rg.ach -gt 0 -and $rg.ach -lt 30) {
                            $achs += [PSCustomObject]@{
                                nombre=$fr.nombre; c0=$rg.c0; ct=$rg.ct; min=$rg.durMin
                                ach=$rg.ach; n=$rg.n; r2=$rg.r2
                                lo=[math]::Min($rg.lo,$rg.achLoSist); hi=[math]::Max($rg.hi,$rg.achHiSist)
                                cext=$refFr.valor; medida=$refFr.medida }
                        }
                    }
                    if ($achs.Count -gt 0) {
                        $inf.Add("") | Out-Null
                        $inf.Add("    RENOVACIÓN DE AIRE (regresión log-lineal, ASTM E741):") | Out-Null
                        $inf.Add("      Supuestos del método (REVISION_RIGOR.md, hallazgo 7): mezcla") | Out-Null
                        $inf.Add("      homogénea del aire, aula VACÍA durante todo el decaimiento, CO2") | Out-Null
                        $inf.Add("      exterior estable y un único punto de medida representativo. Si") | Out-Null
                        $inf.Add("      quedó personal en el aula durante la franja *VACÍO usada aquí, el") | Out-Null
                        $inf.Add("      CO2 que generan subestima el ACH real: verificar en campo.") | Out-Null
                        $inf.Add("      El R2 mide si el decaimiento se ajusta de verdad a una") | Out-Null
                        $inf.Add("      exponencial: es la comprobación del supuesto de mezcla.") | Out-Null
                        foreach ($a in $achs) {
                            $inf.Add(("      [{0}]  {1:N0} -> {2:N0} ppm en {3:N0} min ({4} lecturas)" -f $a.nombre, $a.c0, $a.ct, $a.min, $a.n)) | Out-Null
                            $inf.Add(("            ACH {0:N1}  (banda {1:N1}-{2:N1})   R2 {3:N3}   {4}" -f $a.ach, $a.lo, $a.hi, $a.r2, (ValorarACH $a.ach))) | Out-Null
                            if ($a.r2 -lt $R2_MEZCLA_MIN) {
                                $inf.Add(("            AVISO: R2 por debajo de {0:N2}. El decaimiento no sigue" -f $R2_MEZCLA_MIN)) | Out-Null
                                $inf.Add("            una exponencial simple: probablemente el aire no está bien") | Out-Null
                                $inf.Add("            mezclado (estratificación térmica, ventilación localizada)") | Out-Null
                                $inf.Add("            o el aula no estuvo vacía todo el tramo. Este ACH no es") | Out-Null
                                $inf.Add("            fiable: comprobar en campo antes de usarlo.") | Out-Null
                            }
                        }
                        $media = ($achs | Measure-Object -Property ach -Average).Average
                        $medLo = ($achs | ForEach-Object { $_.lo } | Measure-Object -Average).Average
                        $medHi = ($achs | ForEach-Object { $_.hi } | Measure-Object -Average).Average
                        $r2min = ($achs | ForEach-Object { $_.r2 } | Measure-Object -Minimum).Minimum
                        $inf.Add(("      Media: {0:N1} renovaciones/hora (banda {1:N1}-{2:N1})  ->  {3}" -f $media, $medLo, $medHi, (ValorarACH $media))) | Out-Null
                        $inf.Add("      La banda combina la incertidumbre estadística de la regresión con") | Out-Null
                        $inf.Add("      la del CO2 exterior de referencia, que no se promedia con más") | Out-Null
                        $inf.Add("      lecturas porque desplaza toda la curva a la vez.") | Out-Null
                        if (-not $achs[0].medida) {
                            $inf.Add("      OJO: la referencia exterior es ESTIMADA, no medida. El ACH real") | Out-Null
                            $inf.Add("      es probablemente MENOR que el que aparece aquí (ver arriba).") | Out-Null
                        }
                        # ¿Alguno de los decaimientos usados es nocturno?
                        # La noche es el único tramo con ocupación nula
                        # GARANTIZADA, que es el supuesto del hallazgo 7. De día
                        # solo puede asumirse (revision-rigor-2.md, hallazgo 22).
                        $hayNoche = $false
                        foreach ($a in $achs) {
                            $frA = $franjas | Where-Object { $_.nombre -eq $a.nombre } | Select-Object -First 1
                            if ($frA -ne $null -and ($frA.ini -ge 1140 -or $frA.fin -le 420)) { $hayNoche = $true }
                        }
                        if (-not $hayNoche) {
                            $inf.Add("      Ninguno de estos decaimientos es nocturno. La noche es el único") | Out-Null
                            $inf.Add("      tramo con ocupación nula GARANTIZADA: de día el aula puede tener") | Out-Null
                            $inf.Add("      alguien dentro sin que el registro lo delate. Para una medida de") | Out-Null
                            $inf.Add("      referencia hace falta una noche registrada. El firmware la graba") | Out-Null
                            $inf.Add("      solo: al identificar un aula NUEVA con el comando E, esa jornada") | Out-Null
                            $inf.Add("      se amplía a 24 h y vuelve sola al horario al día siguiente. Si no") | Out-Null
                            $inf.Add("      aparece, comprueba que el reloj estaba en hora al instalar (sin") | Out-Null
                            $inf.Add("      fecha válida la ampliación no se arma) y que hay una franja") | Out-Null
                            $inf.Add("      nocturna en franjas.txt, por ejemplo  19:00-23:59=Noche *VACÍO.") | Out-Null
                        }
                        $inf.Add("      Referencia: las guías internacionales fijan un mínimo de 4 ACH") | Out-Null
                        $inf.Add("      en aulas; los CDC recomiendan 5. Por debajo de 3 se considera bajo.") | Out-Null
                        $inf.Add("      La cifra puntual no debe leerse con más precisión que la banda:") | Out-Null
                        $inf.Add("      la conclusión cualitativa (categoría) es lo que se sostiene.") | Out-Null
                        if ($media -lt 4) {
                            $inf.Add("      Esta aula NO alcanza el mínimo recomendado: el problema no es") | Out-Null
                            $inf.Add("      de umbral puntual sino de capacidad de ventilación del espacio.") | Out-Null
                        }
                    } else {
                        $inf.Add("") | Out-Null
                        $inf.Add("    RENOVACIÓN DE AIRE: no calculable en esta jornada.") | Out-Null
                        $inf.Add("      El método requiere una ventana sin ocupación de al menos 15 min,") | Out-Null
                        $inf.Add("      5 lecturas y una caída de CO2 de 200 ppm o más. Si el aula no se") | Out-Null
                        $inf.Add("      carga lo suficiente, o el recreo es corto, no hay decaimiento") | Out-Null
                        $inf.Add("      suficiente para medirlo.") | Out-Null
                    }
                }

                # ── CONFORT HIGROTÉRMICO ──
                $fTH = $fDia | Where-Object { $_.estado -notlike "*ERR_TH*" } | Sort-Object segundos -Stable
                if ($fTH.Count -gt 2) {
                    $inf.Add("") | Out-Null
                    $inf.Add("  CONFORT HIGROTÉRMICO") | Out-Null

                    # Deriva térmica de la jornada
                    $tIni = $fTH[0].temp
                    $tFin = $fTH[$fTH.Count-1].temp
                    $tMax = ($fTH | Measure-Object -Property temp -Maximum).Maximum
                    # Formato de 3 secciones (positiva;negativa;cero): con solo 2 secciones,
                    # .NET puede mostrar un signo doble ("-+0.0") cuando un valor negativo
                    # redondea a cero al decimal mostrado. Detectado al verificar el hallazgo 4.
                    $inf.Add(("    Deriva térmica de la jornada: {0:+0.0;-0.0;0.0} C   ({1:N1} -> {2:N1})" -f ($tFin-$tIni), $tIni, $tFin)) | Out-Null
                    if (($tMax - $tIni) -gt 5) {
                        $inf.Add(("      El aula gana {0:N1} C a lo largo del día. Una deriva alta apunta" -f ($tMax-$tIni))) | Out-Null
                        $inf.Add("      a ganancias no controladas (solar, ocupación) o inercia escasa.") | Out-Null
                    }

                    # Punto de rocío
                    $rocios = @()
                    foreach ($f in $fTH) {
                        $pr = PuntoRocio $f.temp $f.hum
                        if ($pr -ne $null) { $rocios += $pr }
                    }
                    if ($rocios.Count -gt 0) {
                        $prMax = ($rocios | Measure-Object -Maximum).Maximum
                        $inf.Add(("    Punto de rocío máximo: {0:N1} C" -f $prMax)) | Out-Null
                        $inf.Add("      Cualquier superficie por debajo de esa temperatura condensa.") | Out-Null
                        if ($prMax -gt 16) {
                            $inf.Add("      Valor elevado: en invierno, con vidrios simples o puentes") | Out-Null
                            $inf.Add("      térmicos, hay riesgo real de condensación y moho.") | Out-Null
                        }
                    }

                    # Índice de calor
                    $his = @()
                    foreach ($f in $fTH) { $his += (IndiceCalor $f.temp $f.hum) }
                    if ($his.Count -gt 0) {
                        $hiMax = ($his | Measure-Object -Maximum).Maximum
                        if ($hiMax -gt $tMax + 0.5) {
                            $idx = 0
                            for ($z=0; $z -lt $his.Count; $z++) { if ($his[$z] -eq $hiMax) { $idx = $z; break } }
                            $inf.Add(("    Índice de calor máximo: {0:N1} C   (sensación con {1:N1} C y {2:N0} % HR)" -f $hiMax, $fTH[$idx].temp, $fTH[$idx].hum)) | Out-Null
                            $inf.Add("      La humedad agrava la sensación térmica: explica quejas que") | Out-Null
                            $inf.Add("      la temperatura por sí sola no justificaría.") | Out-Null
                            $inf.Add("      Rothfusz es una fórmula EXTERIOR (sombra, viento ligero), sin") | Out-Null
                            $inf.Add("      validar en interiores: valor orientativo de sensación térmica,") | Out-Null
                            $inf.Add("      no una medida de confort. Ver documento de proyecto, §7.3.") | Out-Null
                        }
                    }
                }
            }

            # ── VALORACIÓN CUALITATIVA DEL ESPACIO ──
            if ($frVacias.Count -gt 0 -and $perfil.Count -gt 0 -and -not $esFinDeSemana) {
                # Eje 1: se toma la franja vacía de MENOR nivel, que representa
                # el fondo estructural del aula sin fuentes excepcionales.
                $fondoEstr = ($perfil | Sort-Object laeq)[0].fondo
                $rt = $reverberacion[$esp]
                $sti = $inteligibilidad[$esp]
                $ge = Grado-Estructural $fondoEstr $rt $sti $u

                $inf.Add("") | Out-Null
                $inf.Add("  VALORACIÓN DEL ESPACIO") | Out-Null
                $inf.Add(("    Eje 1 - Calidad estructural:  {0}" -f (Letra $ge.global))) | Out-Null
                $inf.Add(("      Ruido de fondo (aula vacía): {0:N1} dB  -> grado {1}" -f $fondoEstr, (Letra $ge.fondo))) | Out-Null
                if ($rt -ne $null -and $rt -gt 0) {
                    $inf.Add(("      Reverberación (RT60):       {0:N2} s   -> grado {1}" -f $rt, (Letra $ge.reverb))) | Out-Null
                    if ($rt -gt $RT_CTE_MAX) {
                        $inf.Add("        Por encima del CTE DB-HR (T <= 0,7 s, aula con mobiliario") | Out-Null
                        $inf.Add("        móvil, V <= 350 m3; supuesto declarado en el documento de") | Out-Null
                        $inf.Add("        proyecto). Si el edificio es anterior al RD 1371/2007 y no") | Out-Null
                        $inf.Add("        ha tenido licencia de obra posterior, el CTE no es exigible:") | Out-Null
                        $inf.Add("        el aula se aleja de los valores que exigiría un edificio") | Out-Null
                        $inf.Add("        de nueva construcción, no los incumple.") | Out-Null
                    }
                } else {
                    $inf.Add("      Reverberación (RT60):       no aportada") | Out-Null
                    $inf.Add("        La valoración estructural queda incompleta. El equipo no mide") | Out-Null
                    $inf.Add("        la reverberación: anótala al identificar el espacio.") | Out-Null
                    $inf.Add("        Ejemplo:  E Aula 3B / calle / RT 0.85") | Out-Null
                    $inf.Add("        Referencia: CTE DB-HR, T <= 0,7 s (aula con mobiliario móvil,") | Out-Null
                    $inf.Add("        V <= 350 m3; supuesto declarado). ANSI/ASA S12.60 converge en") | Out-Null
                    $inf.Add("        0,6 s para aulas de hasta 283 m3: referencia internacional.") | Out-Null
                }
                if ($sti -ne $null -and $sti -gt 0) {
                    $inf.Add(("      Inteligibilidad (STI):      {0:N2}    -> grado {1}" -f $sti, (Letra $ge.sti))) | Out-Null
                    if ($sti -lt $STI_DIN_MIN) {
                        $inf.Add("        Por debajo del criterio DIN 18041 (>= 0,65) para salas de") | Out-Null
                        $inf.Add("        comunicación -- referencia internacional de buena práctica,") | Out-Null
                        $inf.Add("        sin equivalente en normativa española. Es la medida DIRECTA") | Out-Null
                        $inf.Add("        de si se entiende la voz del docente, no una predicción.") | Out-Null
                    }
                }
                $inf.Add("      Marco normativo: CTE DB-HR (reverberación, España) es el criterio") | Out-Null
                $inf.Add("      principal. ANSI/ASA S12.60 (fondo, 35 dB) y DIN 18041 (STI) se") | Out-Null
                $inf.Add("      citan como referencias internacionales de buena práctica, sin") | Out-Null
                $inf.Add("      equivalente en normativa española para aulas. Este eje evalúa el") | Out-Null
                $inf.Add("      EDIFICIO, con el aula desocupada.") | Out-Null

                # Eje 2: condiciones durante la actividad lectiva
                $frLect = $franjas | Where-Object { -not $_.vacio }
                $filasAct = @()
                foreach ($fr in $frLect) {
                    $filasAct += $fDia | Where-Object { $_.segundos -ge ($fr.ini*60) -and $_.segundos -lt ($fr.fin*60) -and $_.estado -notlike "*ERR_DB*" -and $_.estado -notlike "*DB_MUESTRA_UNICA*" -and $_.estado -notlike "*DB_INCOMPLETO*" -and $_.laeq -gt 0 }
                }
                if ($filasAct.Count -gt 0) {
                    $lqAct = LaeqGlobal $filasAct
                    $sfAct = Stats ($filasAct.fondo)
                    $rangos = $filasAct | ForEach-Object { $_.maxF - $_.fondo }
                    $srAct = Stats $rangos
                    $evTot = ($filasAct | Measure-Object -Property eventos -Sum).Sum
                    $horas = $filasAct.Count * ($intervaloSeg / 3600.0)
                    $evHora = if ($horas -gt 0) { $evTot / $horas } else { 0 }
                    $gAct = GradoNivelDb $lqAct $u
                    $perfAct = PerfilFluctuacion $srAct.avg $evHora $lqAct $u

                    $inf.Add("") | Out-Null
                    $inf.Add(("    Eje 2 - Condiciones en actividad:  {0}  ({1})" -f (Letra $gAct), (PalabraGrado $gAct))) | Out-Null
                    $inf.Add(("      LAeq de actividad:      {0,5:N1} dB" -f $lqAct)) | Out-Null
                    $inf.Add(("      Rango dinámico:         {0,5:N1} dB" -f $srAct.avg)) | Out-Null
                    $inf.Add(("      Eventos por hora:       {0,5:N0}" -f $evHora)) | Out-Null
                    if ($perfAct -ne $null) { $inf.Add(("      Perfil: {0}" -f $perfAct)) | Out-Null }
                    $inf.Add("      El grado sale del NIVEL, con los tramos de umbrales.txt. La") | Out-Null
                    $inf.Add("      fluctuación se informa aparte y no modifica la letra: el proyecto") | Out-Null
                    $inf.Add("      sigue a BREATHE en que la fluctuación importa tanto o más que el") | Out-Null
                    $inf.Add("      nivel medio, pero no existe escala con la que graduarla, y fabricar") | Out-Null
                    $inf.Add("      un umbral para mover una nota fue el error del hallazgo 24.") | Out-Null
                    $inf.Add("      Estos tramos NO son normativos: ninguna norma fija el nivel") | Out-Null
                    $inf.Add("      aceptable de un aula ocupada. Evalúan el USO y la acústica interior.") | Out-Null
                }
            }

            # Notas de ese día y espacio
            $nd = $notas | Where-Object { $_.espacio -eq $esp -and $_.ts.StartsWith($d) }
            if ($nd.Count -gt 0) {
                $inf.Add("") | Out-Null
                $inf.Add("  ANOTACIONES:") | Out-Null
                foreach ($nn in $nd) { $inf.Add(("    {0}  {1}" -f $nn.ts.Substring(11,5), $nn.texto)) | Out-Null }
            }
        }
        $inf.Add("") | Out-Null
    }

    # ── Filas con marca de tiempo no válida (revision-rigor-3.md, hallazgo 26) ──
    # No se pueden atribuir a ninguna jornada, así que no se analizan por días.
    # Antes formaban una jornada "0000-00-00" con síntesis y nota propias, y
    # resultaba ser la única del informe con una A: le faltaba el eje acústico
    # -sus filas caían fuera de toda franja- y por eso ningún eje la penalizaba.
    if ($sinFecha.Count -gt 0) {
        $inf.Add("====================================================================") | Out-Null
        $inf.Add("  MARCA DE TIEMPO NO VÁLIDA") | Out-Null
        $inf.Add("====================================================================") | Out-Null
        $inf.Add(("  {0} registros ({1:N1} % del total) no llevan una fecha utilizable." -f `
                  $sinFecha.Count, (Pct $sinFecha.Count ($filas.Count + $sinFecha.Count)))) | Out-Null
        $inf.Add("  Ocurre cuando el DS3231 no responde o ha perdido la hora: el firmware") | Out-Null
        $inf.Add("  escribe 0000-00-00T00:00:00 y marca la fila con ERR_RTC.") | Out-Null
        $inf.Add("  QUEDAN FUERA del análisis por jornadas y por franjas: sin hora no se") | Out-Null
        $inf.Add("  sabe si corresponden a una clase, a un recreo o a la noche.") | Out-Null
        $sfT = Stats (($sinFecha | Where-Object { $_.estado -notlike "*ERR_TH*" }).temp)
        $sfC = Stats (($sinFecha | Where-Object { $_.estado -notlike "*ERR_CO2*" -and $_.co2 -gt 0 }).co2)
        if ($sfT) { $inf.Add(("  Rango registrado: T {0:N1}-{1:N1} C" -f $sfT.min, $sfT.max)) | Out-Null }
        if ($sfC) { $inf.Add(("                    CO2 {0:N0}-{1:N0} ppm" -f $sfC.min, $sfC.max)) | Out-Null }
        $inf.Add("  Ajusta el reloj con el comando T y comprueba la pila CR2032 del DS3231.") | Out-Null
        $inf.Add("") | Out-Null
    }

    # ── Calibraciones del sensor de CO2 (comando C CALIBRAR) ──
    # Una calibración de fondo redefine el cero del sensor. Si ocurre ANTES del
    # registro es exactamente lo que pide el protocolo; si ocurre EN MEDIO, la
    # serie de CO2 tiene un escalón artificial en ese instante y compararla de
    # un lado a otro no significa nada.
    if ($calibraciones.Count -gt 0 -and $filas.Count -gt 0) {
        $tsOrd = $filas.ts | Sort-Object
        $tsMin = $tsOrd[0]; $tsMax = $tsOrd[$tsOrd.Count-1]
        $inf.Add("====================================================================") | Out-Null
        $inf.Add("  CALIBRACIÓN DEL SENSOR DE CO2") | Out-Null
        $inf.Add("====================================================================") | Out-Null
        foreach ($cal in $calibraciones) {
            $inf.Add(("  {0}   {1}   [{2}]" -f $cal.ts.Replace("T"," "), $cal.texto, $cal.espacio)) | Out-Null
            if ($cal.ts -gt $tsMin -and $cal.ts -lt $tsMax) {
                if ($cal.texto -like "OK*") {
                    $inf.Add("    [!!] Se calibró EN MEDIO del registro. La línea base del sensor") | Out-Null
                    $inf.Add("         cambió en ese instante: las lecturas de CO2 anteriores y") | Out-Null
                    $inf.Add("         posteriores NO son comparables entre sí, y un salto de") | Out-Null
                    $inf.Add("         decenas de ppm se leería como un cambio de ventilación que") | Out-Null
                    $inf.Add("         no existió. Analiza por separado los dos tramos, o descarta") | Out-Null
                    $inf.Add("         el anterior a la calibración.") | Out-Null
                } else {
                    $inf.Add("    [i]  Intento de calibración no confirmado por el sensor: la línea") | Out-Null
                    $inf.Add("         base NO cambió, la serie es continua.") | Out-Null
                }
            } else {
                $inf.Add("    [OK] Fuera del periodo registrado: es lo que pide el protocolo.") | Out-Null
            }
        }
        $inf.Add("") | Out-Null
    }

    # ── Fiabilidad global ──
    $conErr = $filas | Where-Object { $_.estado -ne "OK" }
    if ($conErr.Count -gt 0) {
        $inf.Add("====================================================================") | Out-Null
        $inf.Add("  FIABILIDAD") | Out-Null
        $inf.Add("====================================================================") | Out-Null
        $inf.Add(("  {0} registros ({1:N1} %) con marcas:" -f $conErr.Count, (Pct $conErr.Count $filas.Count))) | Out-Null
        foreach ($m in @("ERR_TH","ERR_CO2","CO2_CALENTANDO","ERR_DB","DB_INCOMPLETO","DB_MUESTRA_UNICA","ERR_RTC","FLASH_BAJA")) {
            $k = ($filas | Where-Object { $_.estado -like "*$m*" }).Count
            if ($k -gt 0) { $inf.Add(("     {0,-18} {1} registros" -f $m, $k)) | Out-Null }
        }
        $inf.Add("  Esas variables quedan excluidas de las estadísticas.") | Out-Null
        $nInc = ($filas | Where-Object { $_.estado -like "*DB_INCOMPLETO*" }).Count
        if ($nInc -gt 0) {
            $inf.Add("") | Out-Null
            $inf.Add("  DB_INCOMPLETO: el intervalo se observó solo en parte porque el hilo") | Out-Null
            $inf.Add("  del firmware estuvo bloqueado. La causa habitual es el sensor de CO2") | Out-Null
            $inf.Add("  sin responder: su lectura tiene 5 s de espera máxima y se lleva hasta") | Out-Null
            $inf.Add("  el 17 % de las muestras de ruido del intervalo. El recuento de eventos") | Out-Null
            $inf.Add("  quedaría infraestimado en esa proporción, así que esas filas se") | Out-Null
            $inf.Add("  excluyen de los indicadores acústicos (revision-rigor-3.md, 29).") | Out-Null
            $inf.Add("  Si aparecen muchas, revisa el cableado y la alimentación del S8.") | Out-Null
        }
        $nMu = ($filas | Where-Object { $_.estado -like "*DB_MUESTRA_UNICA*" }).Count
        if ($nMu -gt 0) {
            $inf.Add("") | Out-Null
            $inf.Add("  DB_MUESTRA_UNICA no es un error: es un intervalo en el que el") | Out-Null
            $inf.Add("  sonómetro no llegó a acumular muestras (primer registro tras un") | Out-Null
            $inf.Add("  arranque o tras un cambio de ventana horaria) y los cuatro niveles") | Out-Null
            $inf.Add("  salen de UNA sola lectura. Rango dinámico y fluctuación valdrían 0") | Out-Null
            $inf.Add("  por construcción, no por silencio, así que esas filas quedan fuera") | Out-Null
            $inf.Add("  de los indicadores acústicos (revision-rigor-2.md, hallazgo 21).") | Out-Null
            $inf.Add("  Su temperatura, humedad y CO2 sí se usan con normalidad.") | Out-Null
        }
        $inf.Add("") | Out-Null
    }

    $inf.Add("====================================================================") | Out-Null
    $inf.Add("  Umbrales: umbrales.txt   |   Franjas: franjas.txt") | Out-Null
    $inf.Add("  Tabla de interpretación completa en el documento de proyecto.") | Out-Null
    $inf.Add("====================================================================") | Out-Null
    return $inf
}

# ── Guardar en formato Excel español ──
$fecha = Get-Date -Format "yyyy-MM-dd_HHmmss"
$carpeta = Join-Path $PSScriptRoot "datos_volcados"
if (-not (Test-Path $carpeta)) { New-Item -ItemType Directory -Path $carpeta | Out-Null }
$fichero = Join-Path $carpeta "datalog_$fecha.csv"

$salida = New-Object System.Collections.Generic.List[string]
$salida.Add("sep=,")
$primera = $true
foreach ($ln in $lineas) {
    if ($primera) { $salida.Add($ln); $primera = $false; continue }
    $campos = $ln.Split(",")
    $nuevos = foreach ($c in $campos) {
        if ($c -match '^-?\d+\.\d+$') { '"' + ($c -replace '\.', ',') + '"' } else { $c }
    }
    $salida.Add(($nuevos -join ","))
}
$salida | Out-File -FilePath $fichero -Encoding UTF8

Write-Host ""
Write-Host "[OK] Volcado completado." -ForegroundColor Green
Write-Host "     Registros: $($lineas.Count - 1)" -ForegroundColor Green
Write-Host "     Fichero:   $fichero" -ForegroundColor Green

# ── Análisis básico ──
$umbrales = Get-Umbrales
$fUmbrales = Join-Path $PSScriptRoot "umbrales.txt"
if (-not (Test-Path $fUmbrales)) {
    Write-Host ""
    Write-Host "[i] No se encontró umbrales.txt: se usan los valores por defecto." -ForegroundColor Yellow
    Write-Host "    Puedes crear ese fichero para ajustarlos sin tocar el script." -ForegroundColor Gray
}

Write-Host ""
$franjas = Get-Franjas
$informe = Get-Análisis $lineas $umbrales $franjas
foreach ($l in $informe) {
    if ($l -match "INCUMPLIMIENTO|riesgo|Riesgo|<--") { Write-Host $l -ForegroundColor Yellow }
    elseif ($l -match "^====") { Write-Host $l -ForegroundColor DarkCyan }
    elseif ($l -match "^  ---") { Write-Host $l -ForegroundColor Cyan }
    else { Write-Host $l }
}

# Guardar el informe junto al CSV
$fInforme = $fichero -replace "\.csv$", "_resumen.txt"
$cabecera = @(
    "RESUMEN DE REGISTRO AMBIENTAL",
    "Generado: $(Get-Date -Format 'yyyy-MM-dd HH:mm')",
    "Datos:    $(Split-Path $fichero -Leaf)",
    "www.acusticaescolar.com",
    ""
)
($cabecera + $informe) | Out-File -FilePath $fInforme -Encoding UTF8
Write-Host ""
Write-Host "[OK] Resumen guardado en: $fInforme" -ForegroundColor Green

Read-Host "`nPulsa Enter para salir"
