@echo off
REM ============================================================
REM volcar_datos.bat
REM Lanzador del script de volcado de datos del datalogger ESP32-S3
REM www.acusticaescolar.com - Licencia MIT
REM
REM Doble clic en este fichero para volcar los datos del ESP32.
REM Debe estar en la misma carpeta que volcar_datos.ps1
REM ============================================================
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0volcar_datos.ps1"
