﻿# ============================================================
# volcar_datos.ps1
# Vuelca el CSV del Registrador Ambiental a un fichero en el PC
# www.acusticaescolar.com - Licencia MIT
#
# Usó normal:     doble clic en volcar_datos.bat
# Puerto manual:  volcar_datos.bat COM3
# Diagnóstico:    volcar_datos.bat COM3 -Verbose
#
# IMPORTANTE: el Monitor Serie del Arduino IDE debe estar CERRADO.
# ============================================================

param(
    [string]$Puerto = "",
    [switch]$Verbose
)

$ErrorActionPreference = "Stop"
$baudRate = 115200

# La consola de Windows no usa UTF-8 por defecto: sin esto los acentos
# se muestran como caracteres extraños.
try {
    [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
    $OutputEncoding = [System.Text.Encoding]::UTF8
} catch { }

# ── Umbrales de valoración ──
# Se leen de umbrales.txt, en la misma carpeta. Si no existe, se crea con
# los valores por defecto. Así pueden actualizarse sin tocar este script.
$umbralesPorDefecto = @{
    T_MIN_LEGAL=17; T_OPTIMO_MIN=20; T_OPTIMO_MAX=24; T_MAX_LEGAL=27; T_RIESGO=30
    HR_MIN_LEGAL=30; HR_OPTIMO_MIN=40; HR_OPTIMO_MAX=60; HR_MAX_LEGAL=70
    CO2_OPTIMO=700; CO2_ACEPTABLE=900; CO2_DEFICIENTE=1200; CO2_RIESGO=1600
    DB_OPTIMO=35; DB_ACEPTABLE=45; DB_NORMAL=55; DB_RIESGO=65
}
function Get-Franjas {
    $f = Join-Path $PSScriptRoot "franjas.txt"
    $lista = @()
    if (Test-Path $f) {
        foreach ($l in (Get-Content $f -Encoding UTF8)) {
            $l = $l.Trim()
            if ($l -eq "" -or $l.StartsWith("#")) { continue }
            if ($l -match "^(\d{1,2}):(\d{2})\s*-\s*(\d{1,2}):(\d{2})\s*=\s*(.+)$") {
                $nom = $Matches[5].Trim()
                $vacio = $false
                if ($nom -match "\*VAC[IÍÃ]\S*O\s*$") {
                    $vacio = $true
                    $nom = ($nom -replace "\*VAC[IÍÃ]\S*O\s*$", "").Trim()
                }
                $lista += [PSCustomObject]@{
                    ini = [int]$Matches[1]*60 + [int]$Matches[2]
                    fin = [int]$Matches[3]*60 + [int]$Matches[4]
                    nombre = $nom
                    vacio = $vacio
                }
            }
        }
    }
    return $lista
}

function Get-Umbrales {
    $f = Join-Path $PSScriptRoot "umbrales.txt"
    $u = $umbralesPorDefecto.Clone()
    if (Test-Path $f) {
        foreach ($l in (Get-Content $f -Encoding UTF8)) {
            $l = $l.Trim()
            if ($l -eq "" -or $l.StartsWith("#")) { continue }
            if ($l -match "^([A-Z0-9_]+)\s*=\s*(-?\d+(\.\d+)?)") {
                $u[$Matches[1]] = [double]$Matches[2]
            }
        }
    }
    return $u
}

Write-Host ""
Write-Host "=== VOLCADO DE DATOS - Registrador Ambiental ===" -ForegroundColor Cyan
Write-Host ""

# ── Localizar puertos candidatos ──
function Get-Candidatos {
    $lista = @()
    try {
        $disp = Get-CimInstance -ClassName Win32_PnPEntity -ErrorAction SilentlyContinue |
                Where-Object { $_.Name -match "\(COM(\d+)\)" }
        foreach ($d in $disp) {
            if ($d.Name -match "\(COM(\d+)\)") {
                $lista += [PSCustomObject]@{
                    Com         = "COM" + $Matches[1]
                    Nombre      = $d.Name
                    Prioritario = ($d.DeviceID -match "VID_(303A|1A86|10C4|0403)")
                }
            }
        }
    } catch { }
    # Fabricante conocido primero
    return @($lista | Where-Object { $_.Prioritario }) +
           @($lista | Where-Object { -not $_.Prioritario })
}

# ── Abrir puerto y esperar a que el dispositivo este LISTO ──
# Al abrir el puerto, la placa puede reiniciarse (señal DTR). Si eso ocurre,
# el firmware ejecuta su diagnóstico de arranque durante unos segundos y no
# atiende comandos. Esta función espera a que termine antes de continuar.
function Open-Registrador {
    param([string]$com)

    $sp = New-Object System.IO.Ports.SerialPort $com, $baudRate, "None", 8, "One"
    $sp.ReadTimeout  = 1500
    $sp.WriteTimeout = 2000
    $sp.DtrEnable = $true
    $sp.RtsEnable = $true
    $sp.ReadBufferSize = 65536      # holgado: el volcado puede ser largo
    $sp.Open()

    Write-Host "      esperando a que el equipo este listo..." -ForegroundColor Gray
    $arrancando = $false
    $listo      = $false
    $limite = (Get-Date).AddSeconds(30)

    while ((Get-Date) -lt $limite) {
        try { $l = $sp.ReadLine().TrimEnd("`r") }
        catch [TimeoutException] {
            # Silencio: si ya vimos el arranque, es que termino; si no, probamos
            if ($arrancando) { $listo = $true; break }
            $sp.WriteLine("H")       # tantear con un comando inofensivo
            continue
        }
        if ($Verbose) { Write-Host "        < $l" -ForegroundColor DarkGray }

        # El equipo se ha reiniciado: hay que esperar al final del diagnóstico
        if ($l -match "DATALOGGER AMBIENTAL|FASE 1|Iniciando") { $arrancando = $true }
        # Señales de que ya esta operativo y atiende comandos
        if ($l -match "Comandos:|componentes OK|Hora del RTC|\[LOG #|Ventana de registro") {
            $listo = $true; break
        }
    }
    if (-not $listo) { Write-Host "      (sin confirmación, se intenta igualmente)" -ForegroundColor DarkYellow }
    Start-Sleep -Milliseconds 500
    $sp.DiscardInBuffer()
    return $sp
}

# ── Determinar el puerto ──
if ($Puerto -ne "") {
    $puertoElegido = $Puerto
    Write-Host "[i] Puerto indicado manualmente: $puertoElegido" -ForegroundColor Yellow
} else {
    $cand = Get-Candidatos
    if ($cand.Count -eq 0) {
        Write-Host "[!] No se ha detectado ningún puerto COM." -ForegroundColor Red
        Write-Host "    Verifica que el registrador esta conectado por USB." -ForegroundColor Yellow
        Read-Host "`nPulsa Enter para salir"; exit 1
    }
    Write-Host "[i] Puertos detectados:" -ForegroundColor Cyan
    foreach ($c in $cand) {
        $m = if ($c.Prioritario) { " <- chip USB-serie conocido" } else { "" }
        Write-Host "      $($c.Nombre)$m" -ForegroundColor Gray
    }
    $puertoElegido = $cand[0].Com
    Write-Host ""
    Write-Host "[i] Usando $puertoElegido" -ForegroundColor Cyan
}

# ── Abrir (una sola vez) ──
try {
    $sp = Open-Registrador $puertoElegido
} catch {
    Write-Host ""
    Write-Host "[!] No se pudo abrir $puertoElegido." -ForegroundColor Red
    Write-Host "    Causas más probables:" -ForegroundColor Yellow
    Write-Host "      - El Monitor Serie del Arduino IDE esta abierto. Ciérralo." -ForegroundColor Yellow
    Write-Host "      - Otro programa esta usando el puerto." -ForegroundColor Yellow
    Write-Host "    Puedes indicar otro puerto:  volcar_datos.bat COM3" -ForegroundColor White
    Read-Host "`nPulsa Enter para salir"; exit 1
}

Write-Host "[OK] Conectado a $puertoElegido" -ForegroundColor Green
Write-Host ""

# ── Solicitar el volcado (con reintentos) ──
$lineas = New-Object System.Collections.Generic.List[string]
$recibidoAlgo = $false

for ($intento = 1; $intento -le 3; $intento++) {
    Write-Host "[i] Solicitando volcado del CSV (intento $intento de 3)..." -ForegroundColor Cyan
    $sp.DiscardInBuffer()
    $sp.WriteLine("D")

    $capturando = $false
    $sp.ReadTimeout = 5000
    $limite = (Get-Date).AddSeconds(90)

    while ((Get-Date) -lt $limite) {
        try { $linea = $sp.ReadLine().TrimEnd("`r") }
        catch [TimeoutException] { if ($capturando) { break } else { break } }
        $recibidoAlgo = $true
        if ($Verbose) { Write-Host "    < $linea" -ForegroundColor DarkGray }

        if ($linea -match "----- INICIO CSV -----") { $capturando = $true; continue }
        if ($linea -match "----- FIN CSV")          { break }
        if ($linea -match "No hay CSV") {
            Write-Host "[!] El equipo responde que no hay datos guardados." -ForegroundColor Yellow
            $sp.Close(); Read-Host "`nPulsa Enter para salir"; exit 1
        }
        if ($capturando -and $linea -notmatch "^\[LOG #") { $lineas.Add($linea) }
    }
    if ($lineas.Count -gt 0) { break }
    Write-Host "      sin respuesta útil, reintentando..." -ForegroundColor DarkYellow
    Start-Sleep -Seconds 2
}
$sp.Close()

if ($lineas.Count -eq 0) {
    Write-Host ""
    Write-Host "[!] No se recibieron datos." -ForegroundColor Red
    if ($recibidoAlgo) {
        Write-Host "    El equipo respondía, pero no envió el bloque de datos." -ForegroundColor Yellow
        Write-Host "    Comprueba con el comando I (en el Monitor Serie) que hay" -ForegroundColor Yellow
        Write-Host "    registros guardados." -ForegroundColor Yellow
    } else {
        Write-Host "    El equipo no respondió en absoluto." -ForegroundColor Yellow
        Write-Host "    Prueba a desconectar y reconectar el cable USB." -ForegroundColor Yellow
    }
    Write-Host ""
    Write-Host "    Para ver el detalle de la comunicación:" -ForegroundColor White
    Write-Host "      volcar_datos.bat $puertoElegido -Verbose" -ForegroundColor White
    Read-Host "`nPulsa Enter para salir"; exit 1
}

# ── Análisis de los datos ──
# Segmenta por ESPACIO (marcas #ESPACIO del CSV), luego por DÍA y dentro de
# cada día por FRANJA horaria. Es la estructura que corresponde a la operativa
# real: el equipo pasa uno o dos días en cada aula, y dentro del día el usó
# del espacio cambia (clase, recreo, comedor, vacío).

function Stats($vals) {
    if ($vals.Count -eq 0) { return $null }
    $m = ($vals | Measure-Object -Minimum -Maximum -Average)
    return @{ min=$m.Minimum; max=$m.Maximum; avg=$m.Average; n=$vals.Count }
}
function Pct($k, $tot) { if ($tot -eq 0) { return 0 } return $k*100/$tot }

# Ratio de intermitencia: que proporción de la energía sonora aportan los
# eventos por encima del ruido de fondo. Es el segundo indicador de fluctuación
# que usó BREATHE, junto al número de eventos.
#   IR = (E_total - E_fondo) / E_total * 100
# Un zumbido constante da IR bajo; un fondo tranquilo roto por interrupciones,
# IR alto. Distingue situaciones que el LAeq por si solo confunde.
function Intermitencia($laeq, $fondo) {
    if ($laeq -le 0 -or $fondo -le 0 -or $fondo -ge $laeq) { return 0 }
    $Et = [math]::Pow(10, $laeq/10.0)
    $Ef = [math]::Pow(10, $fondo/10.0)
    return [math]::Max(0, ($Et - $Ef) / $Et * 100)
}

# Resta energética de dos niveles en dB: cuánto aporta una fuente adicional
# sobre un fondo conocido. Devuelve $null si el total no supera al fondo.
function RestaEnergetica($total, $fondo) {
    if ($total -le $fondo) { return $null }
    $d = [math]::Pow(10, $total/10.0) - [math]::Pow(10, $fondo/10.0)
    if ($d -le 0) { return $null }
    return 10*[math]::Log10($d)
}

# Peso relativo de una fuente sobre la energía total (porcentaje)
function PesoEnergetico($parte, $total) {
    if ($total -le 0) { return 0 }
    return [math]::Pow(10, $parte/10.0) / [math]::Pow(10, $total/10.0) * 100
}

# LAeq de un conjunto de intervalos: promedio ENERGÉTICO, no aritmetico
function LaeqGlobal($filas) {
    $v = $filas | Where-Object { $_.estado -notlike "*ERR_DB*" -and $_.laeq -gt 0 }
    if ($v.Count -eq 0) { return $null }
    $s = 0.0
    foreach ($f in $v) { $s += [math]::Pow(10, $f.laeq/10.0) }
    return 10*[math]::Log10($s/$v.Count)
}

# Resumen compacto de un conjunto de filas (una franja o un día)
function Resumen-Bloque($filas, $u, $inf, $sangria) {
    $s = $sangria
    $n = $filas.Count
    if ($n -eq 0) { return }

    $vT = ($filas | Where-Object { $_.estado -notlike "*ERR_TH*" }).temp
    $vC = ($filas | Where-Object { $_.estado -notlike "*ERR_CO2*" -and $_.co2 -gt 0 }).co2
    $vD = $filas | Where-Object { $_.estado -notlike "*ERR_DB*" -and $_.laeq -gt 0 }

    $st = Stats $vT; $sc = Stats $vC
    $laeq = LaeqGlobal $filas

    $lin = "$s"
    if ($st)   { $lin += ("T {0,4:N1}-{1,4:N1} C" -f $st.min, $st.max) } else { $lin += "T    n/d      " }
    if ($sc)   { $lin += ("  CO2 {0,4:N0}-{1,4:N0} ppm" -f $sc.min, $sc.max) } else { $lin += "  CO2   n/d     " }
    if ($laeq -ne $null) { $lin += ("  LAeq {0,4:N1} dB" -f $laeq) }
    $inf.Add($lin) | Out-Null

    # Detalles solo si hay algo destacable
    $avisos = @()
    if ($st -and $st.max -gt $u.T_MAX_LEGAL) {
        $k = ($vT | Where-Object { $_ -gt $u.T_MAX_LEGAL }).Count
        $avisos += ("temperatura sobre el máximo legal el {0:N0} % del tiempo" -f (Pct $k $st.n))
    }
    if ($sc -and $sc.max -ge $u.CO2_DEFICIENTE) {
        $k = ($vC | Where-Object { $_ -ge $u.CO2_DEFICIENTE }).Count
        $avisos += ("CO2 en mala calidad el {0:N0} % del tiempo" -f (Pct $k $sc.n))
    }
    if ($vD.Count -gt 0) {
        $rangos = $vD | ForEach-Object { $_.max - $_.fondo }
        $sr = Stats $rangos
        $ev = ($vD | Measure-Object -Property eventos -Sum).Sum
        $sf = Stats ($vD.fondo)
        $ir = Intermitencia $laeq $sf.avg
        $avisos += ("fondo {0:N0} dB, rango dinámico {1:N0} dB, {2} eventos, intermitencia {3:N0} %" -f $sf.avg, $sr.avg, $ev, $ir)
    }
    foreach ($a in $avisos) { $inf.Add("$s   - $a") | Out-Null }
}

function Get-Análisis {
    param([System.Collections.Generic.List[string]]$lineas, $u, $franjas)

    $inf = New-Object System.Collections.Generic.List[string]
    if ($lineas.Count -lt 2) { $inf.Add("Sin registros que analizar.") | Out-Null; return $inf }

    # ── Parsear: filas de datos y marcas ──
    $filas = @()
    $notas = @()
    $espacio = "sin identificar"
    $exposición = ""
    $exposiciones = @{}
    $reverberacion = @{}
    $inteligibilidad = @{}
    foreach ($l in $lineas) {
        if ($l.StartsWith("#ESPACIO,")) {
            $p = $l.Split(",")
            if ($p.Count -ge 3) {
                # Formato: "Aula 3B / calle / RT 0.85 / STI 0.62"
                # El nombre es el primer campo; el resto son opcionales y su
                # orden es indiferente. Si el comando se repite para el mismo
                # espacio, los datos se FUSIONAN: permite anotar la
                # reverberacion mas tarde, cuando se haya medido.
                $campos = ($p[2..($p.Count-1)] -join ",").Split("/")
                $espacio = $campos[0].Trim()
                for ($k = 1; $k -lt $campos.Count; $k++) {
                    $c = $campos[$k].Trim()
                    if ($c -match "^(?i)sti\s*[:=]?\s*([\d.,]+)") {
                        $inteligibilidad[$espacio] = [double]($Matches[1] -replace ",", ".")
                    }
                    elseif ($c -match "^(?i)rt\s*[:=]?\s*([\d.,]+)") {
                        $reverberacion[$espacio] = [double]($Matches[1] -replace ",", ".")
                    }
                    elseif ($c -match "(?i)^(calle|patio|interior|mixta)") {
                        $exposiciones[$espacio] = $Matches[1].ToLower()
                    }
                }
                if (-not $exposiciones.ContainsKey($espacio)) { $exposiciones[$espacio] = "" }
            }
            continue
        }
        if ($l.StartsWith("#NOTA,")) {
            $p = $l.Split(",")
            if ($p.Count -ge 3) { $notas += [PSCustomObject]@{ ts=$p[1]; espacio=$espacio; texto=($p[2..($p.Count-1)] -join ",") } }
            continue
        }
        if ($l.StartsWith("timestamp")) { continue }
        $c = $l.Split(",")
        if ($c.Count -lt 10) { continue }
        try {
            $filas += [PSCustomObject]@{
                espacio = $espacio
                ts      = $c[0]
                día     = $c[0].Substring(0,10)
                minutos = [int]$c[0].Substring(11,2)*60 + [int]$c[0].Substring(14,2)
                temp    = [double]($c[1] -replace ",", ".")
                hum     = [double]($c[2] -replace ",", ".")
                co2     = [int]$c[3]
                laeq    = [int]$c[4]
                fondo   = [int]$c[5]
                maxF    = [int]$c[6]
                max     = [int]$c[7]
                eventos = [int]$c[8]
                estado  = $c[9]
            }
        } catch { }
    }
    if ($filas.Count -eq 0) { $inf.Add("No se pudo interpretar ningún registro.") | Out-Null; return $inf }

    $inf.Add("====================================================================") | Out-Null
    $inf.Add("  ANÁLISIS DEL REGISTRO") | Out-Null
    $inf.Add("====================================================================") | Out-Null
    $inf.Add("") | Out-Null
    # Deducir el intervalo de registro a partir de dos marcas consecutivas
    $intervaloSeg = 30
    if ($filas.Count -gt 2) {
        try {
            $t1 = [datetime]::ParseExact($filas[1].ts, "yyyy-MM-ddTHH:mm:ss", $null)
            $t2 = [datetime]::ParseExact($filas[2].ts, "yyyy-MM-ddTHH:mm:ss", $null)
            $d = ($t2 - $t1).TotalSeconds
            if ($d -gt 0 -and $d -lt 600) { $intervaloSeg = $d }
        } catch { }
    }
    $inf.Add(("  Registros: {0}   (intervalo {1:N0} s)" -f $filas.Count, $intervaloSeg)) | Out-Null

    $espacios = $filas.espacio | Select-Object -Unique
    $inf.Add(("  Espacios:  {0}" -f ($espacios -join ", "))) | Out-Null
    if ($espacios -contains "sin identificar") {
        $inf.Add("  AVISO: hay registros sin identificar. Usa el comando E al") | Out-Null
        $inf.Add("         instalar el equipo para saber a que aula pertenecen.") | Out-Null
    }
    $sinExpo = $espacios | Where-Object { [string]::IsNullOrEmpty($exposiciones[$_]) }
    if ($sinExpo.Count -gt 0) {
        $inf.Add(("  AVISO: sin exposición indicada en: {0}" -f ($sinExpo -join ", "))) | Out-Null
        $inf.Add("         Indicala al identificar el espacio:  E Aula 3B / calle") | Out-Null
        $inf.Add("         Sin ella no puede interpretarse el ruido exterior.") | Out-Null
    }
    $inf.Add("") | Out-Null

    # ── Recorrido por espacio y día ──
    foreach ($esp in $espacios) {
        $fEsp = $filas | Where-Object { $_.espacio -eq $esp }
        $inf.Add("====================================================================") | Out-Null
        $expo = $exposiciones[$esp]
        if ([string]::IsNullOrEmpty($expo)) { $expo = "sin especificar" }
        $inf.Add(("  ESPACIO: {0}    ({1} registros)" -f $esp, $fEsp.Count)) | Out-Null
        $inf.Add(("  Exposición: {0}" -f $expo)) | Out-Null
        $inf.Add("====================================================================") | Out-Null

        $días = $fEsp.día | Select-Object -Unique | Sort-Object
        foreach ($d in $días) {
            $fDia = $fEsp | Where-Object { $_.día -eq $d }
            $inf.Add("") | Out-Null
            $inf.Add(("  --- {0}   ({1} registros) ---" -f $d, $fDia.Count)) | Out-Null

            # Resumen del día completo
            $inf.Add("  JORNADA COMPLETA:") | Out-Null
            Resumen-Bloque $fDia $u $inf "    "

            # Desglose por franjas
            if ($franjas.Count -gt 0) {
                $inf.Add("") | Out-Null
                $inf.Add("  POR FRANJAS:") | Out-Null
                foreach ($fr in $franjas) {
                    $fFr = $fDia | Where-Object { $_.minutos -ge $fr.ini -and $_.minutos -lt $fr.fin }
                    if ($fFr.Count -eq 0) { continue }
                    $inf.Add(("    [{0}]  {1} registros" -f $fr.nombre, $fFr.Count)) | Out-Null
                    Resumen-Bloque $fFr $u $inf "      "
                }
            }

            # ── Origen del ruido: exógeno vs endógeno ──
            # Las franjas sin ocupación miden lo que entra de fuera. Cada una
            # se trata por separado: el ruido exterior a las 7:30 no es el
            # mismo que a las 13:00, ni que en el recreo con el patio lleno.
            $frVacias = $franjas | Where-Object { $_.vacio }
            if ($frVacias.Count -gt 0) {
                $perfil = @()
                foreach ($fr in $frVacias) {
                    $fF = $fDia | Where-Object { $_.minutos -ge $fr.ini -and $_.minutos -lt $fr.fin -and $_.estado -notlike "*ERR_DB*" -and $_.laeq -gt 0 }
                    if ($fF.Count -eq 0) { continue }
                    $lq = LaeqGlobal $fF
                    $sf = Stats ($fF.fondo)
                    $perfil += [PSCustomObject]@{
                        nombre = $fr.nombre; centro = ($fr.ini + $fr.fin)/2
                        laeq = $lq; fondo = $sf.avg; n = $fF.Count
                    }
                }
                if ($perfil.Count -gt 0) {
                    $inf.Add("") | Out-Null
                    $inf.Add("  RUIDO EXTERIOR (franjas sin ocupación):") | Out-Null
                    foreach ($p in $perfil) {
                        $inf.Add(("    {0,-22} LAeq {1,4:N1} dB   fondo {2,4:N1} dB" -f $p.nombre, $p.laeq, $p.fondo)) | Out-Null
                    }
                    $vmin = ($perfil | Sort-Object laeq)[0]
                    $vmax = ($perfil | Sort-Object laeq -Descending)[0]
                    if ($perfil.Count -gt 1 -and ($vmax.laeq - $vmin.laeq) -ge 5) {
                        $inf.Add(("    El ruido exterior varia {0:N0} dB entre franjas: mínimo en {1}, máximo en {2}." -f ($vmax.laeq-$vmin.laeq), $vmin.nombre, $vmax.nombre)) | Out-Null
                    }

                    # Contribución de fuentes: solo tiene sentido si el ruido de
                    # las franjas vacías representa el exterior estructural. En un
                    # aula orientada al patio no es así: hay alumnos esperando al
                    # comedor, educación física, recreos escalonados. Ahi se omite
                    # el calculo en lugar de dar un número engañoso.
                    $expoEsp = $exposiciones[$esp]
                    if ($expoEsp -eq "patio") {
                        $inf.Add("") | Out-Null
                        $inf.Add("  ORIGEN DEL RUIDO: no se estima.") | Out-Null
                        $inf.Add("    El aula da al patio, de modo que las franjas sin ocupación no") | Out-Null
                        $inf.Add("    reflejan el ruido exterior estructural sino la actividad escolar") | Out-Null
                        $inf.Add("    al aire libre (espera del comedor, educación física, recreos de") | Out-Null
                        $inf.Add("    otros grupos). Los niveles de esas franjas siguen siendo validos") | Out-Null
                        $inf.Add("    y están arriba: documentan un ruido exógeno real, pero no") | Out-Null
                        $inf.Add("    comparable con el marco de estudios sobre ruido de tráfico.") | Out-Null
                        $lineasFuente = @()
                    } else {
                    $frOcup = $franjas | Where-Object { -not $_.vacio }
                    $lineasFuente = @()
                    foreach ($fr in $frOcup) {
                        $fF = $fDia | Where-Object { $_.minutos -ge $fr.ini -and $_.minutos -lt $fr.fin -and $_.estado -notlike "*ERR_DB*" -and $_.laeq -gt 0 }
                        if ($fF.Count -eq 0) { continue }
                        $lqTotal = LaeqGlobal $fF
                        # Referencia del ruido exterior. Se usa la franja vacía más
                        # próxima en el tiempo, PERO descartando las que están muy por
                        # encima del resto: una franja vacía puede tener una fuente
                        # excepcional (el patio durante el recreo) que no representa
                        # el exterior habitual durante la clase.
                        $centroFr = ($fr.ini + $fr.fin)/2
                        $niveles = ($perfil.laeq | Sort-Object)
                        $mediana = $niveles[[int]($niveles.Count/2)]
                        $candidatas = $perfil | Where-Object { $_.laeq -le ($mediana + 6) }
                        if ($candidatas.Count -eq 0) { $candidatas = $perfil }
                        $ref = $candidatas | Sort-Object { [math]::Abs($_.centro - $centroFr) } | Select-Object -First 1
                        $descartada = $perfil | Where-Object { $_.laeq -gt ($mediana + 6) }
                        $endo = RestaEnergetica $lqTotal $ref.laeq
                        if ($endo -ne $null) {
                            $pExo = PesoEnergetico $ref.laeq $lqTotal
                            $lineasFuente += ("    {0,-22} total {1,4:N1} dB = actividad {2,4:N1} dB + exterior {3,4:N1} dB ({4:N0} %)" -f $fr.nombre, $lqTotal, $endo, $ref.laeq, $pExo)
                        } else {
                            $lineasFuente += ("    {0,-22} total {1,4:N1} dB: no supera al exterior de referencia ({2:N1} dB)" -f $fr.nombre, $lqTotal, $ref.laeq)
                        }
                    }
                    }
                    if ($lineasFuente.Count -gt 0) {
                        $inf.Add("") | Out-Null
                        $inf.Add("  ORIGEN DEL RUIDO (referencia: franja vacía más próxima):") | Out-Null
                        foreach ($lf in $lineasFuente) { $inf.Add($lf) | Out-Null }
                        $inf.Add("    Un peso alto del exterior apunta a la envolvente del edificio;") | Out-Null
                        $inf.Add("    uno bajo, a la actividad y la acústica interior del aula.") | Out-Null
                        $anom = $perfil | Where-Object { $_.laeq -gt ($mediana + 6) }
                        if ($anom.Count -gt 0) {
                            $inf.Add("") | Out-Null
                            foreach ($an in $anom) {
                                $inf.Add(("    NOTA: la franja «{0}» ({1:N1} dB) queda fuera de la referencia por" -f $an.nombre, $an.laeq)) | Out-Null
                                $inf.Add("          estar muy por encima de las demas franjas vacías. Refleja una") | Out-Null
                                $inf.Add("          fuente exterior puntual (p. ej. el patio), no el ruido habitual.") | Out-Null
                            }
                        }
                    }
                }
            }

            # ── VALORACIÓN CUALITATIVA DEL ESPACIO ──
            if ($frVacias.Count -gt 0 -and $perfil.Count -gt 0) {
                # Eje 1: se toma la franja vacía de MENOR nivel, que representa
                # el fondo estructural del aula sin fuentes excepcionales.
                $fondoEstr = ($perfil | Sort-Object laeq)[0].fondo
                $rt = $reverberacion[$esp]
                $sti = $inteligibilidad[$esp]
                $ge = Grado-Estructural $fondoEstr $rt $sti

                $inf.Add("") | Out-Null
                $inf.Add("  VALORACIÓN DEL ESPACIO") | Out-Null
                $inf.Add(("    Eje 1 - Calidad estructural:  {0}" -f (Letra $ge.global))) | Out-Null
                $inf.Add(("      Ruido de fondo (aula vacía): {0:N1} dB  -> grado {1}" -f $fondoEstr, (Letra $ge.fondo))) | Out-Null
                if ($rt -ne $null -and $rt -gt 0) {
                    $inf.Add(("      Reverberación (RT60):       {0:N2} s   -> grado {1}" -f $rt, (Letra $ge.reverb))) | Out-Null
                } else {
                    $inf.Add("      Reverberación (RT60):       no aportada") | Out-Null
                    $inf.Add("        La valoración estructural queda incompleta. El equipo no mide") | Out-Null
                    $inf.Add("        la reverberación: anótala al identificar el espacio.") | Out-Null
                    $inf.Add("        Ejemplo:  E Aula 3B / calle / RT 0.85") | Out-Null
                    $inf.Add("        Referencia ANSI/ASA S12.60: máx. 0,6 s (aulas hasta 283 m3).") | Out-Null
                }
                if ($sti -ne $null -and $sti -gt 0) {
                    $inf.Add(("      Inteligibilidad (STI):      {0:N2}    -> grado {1}" -f $sti, (Letra $ge.sti))) | Out-Null
                    if ($sti -lt 0.65) {
                        $inf.Add("        Por debajo del criterio DIN 18041 (>= 0,65) para salas") | Out-Null
                        $inf.Add("        de comunicación. Es la medida DIRECTA de si se entiende") | Out-Null
                        $inf.Add("        la voz del docente, no una prediccion indirecta.") | Out-Null
                    }
                }
                $inf.Add("      Referencia: ANSI/ASA S12.60 fija 35 dB de fondo y 0,6 s de RT60") | Out-Null
                $inf.Add("      con el aula desocupada. Este eje evalúa el EDIFICIO.") | Out-Null

                # Eje 2: condiciones durante la actividad lectiva
                $frLect = $franjas | Where-Object { -not $_.vacio }
                $filasAct = @()
                foreach ($fr in $frLect) {
                    $filasAct += $fDia | Where-Object { $_.minutos -ge $fr.ini -and $_.minutos -lt $fr.fin -and $_.estado -notlike "*ERR_DB*" -and $_.laeq -gt 0 }
                }
                if ($filasAct.Count -gt 0) {
                    $lqAct = LaeqGlobal $filasAct
                    $sfAct = Stats ($filasAct.fondo)
                    $rangos = $filasAct | ForEach-Object { $_.max - $_.fondo }
                    $srAct = Stats $rangos
                    $evTot = ($filasAct | Measure-Object -Property eventos -Sum).Sum
                    $horas = $filasAct.Count * ($intervaloSeg / 3600.0)
                    $evHora = if ($horas -gt 0) { $evTot / $horas } else { 0 }
                    $irAct = Intermitencia $lqAct $sfAct.avg
                    $val = Valorar-Actividad $lqAct $srAct.avg $evHora $irAct

                    $inf.Add("") | Out-Null
                    $inf.Add(("    Eje 2 - Condiciones en actividad:  {0}" -f $val)) | Out-Null
                    $inf.Add(("      LAeq de actividad:   {0,5:N1} dB" -f $lqAct)) | Out-Null
                    $inf.Add(("      Rango dinámico:      {0,5:N1} dB" -f $srAct.avg)) | Out-Null
                    $inf.Add(("      Eventos por hora:    {0,5:N0}" -f $evHora)) | Out-Null
                    $inf.Add(("      Intermitencia:       {0,5:N0} %" -f $irAct)) | Out-Null
                    $inf.Add("      Este eje pondera la FLUCTUACIÓN por encima del nivel medio,") | Out-Null
                    $inf.Add("      siguiendo el estudio BREATHE. Sus umbrales NO son normativos:") | Out-Null
                    $inf.Add("      no existe norma que los fije. Evalúa el USO y la acústica interior.") | Out-Null
                }
            }

            # Notas de ese día y espacio
            $nd = $notas | Where-Object { $_.espacio -eq $esp -and $_.ts.StartsWith($d) }
            if ($nd.Count -gt 0) {
                $inf.Add("") | Out-Null
                $inf.Add("  ANOTACIONES:") | Out-Null
                foreach ($nn in $nd) { $inf.Add(("    {0}  {1}" -f $nn.ts.Substring(11,5), $nn.texto)) | Out-Null }
            }
        }
        $inf.Add("") | Out-Null
    }

    # ── Fiabilidad global ──
    $conErr = $filas | Where-Object { $_.estado -ne "OK" }
    if ($conErr.Count -gt 0) {
        $inf.Add("====================================================================") | Out-Null
        $inf.Add("  FIABILIDAD") | Out-Null
        $inf.Add("====================================================================") | Out-Null
        $inf.Add(("  {0} registros ({1:N1} %) con marcas de error:" -f $conErr.Count, (Pct $conErr.Count $filas.Count))) | Out-Null
        foreach ($m in @("ERR_TH","ERR_CO2","ERR_DB","ERR_RTC","FLASH_BAJA")) {
            $k = ($filas | Where-Object { $_.estado -like "*$m*" }).Count
            if ($k -gt 0) { $inf.Add(("     {0,-12} {1} registros" -f $m, $k)) | Out-Null }
        }
        $inf.Add("  Esas variables quedan excluidas de las estadísticas.") | Out-Null
        $inf.Add("") | Out-Null
    }

    $inf.Add("====================================================================") | Out-Null
    $inf.Add("  Umbrales: umbrales.txt   |   Franjas: franjas.txt") | Out-Null
    $inf.Add("  Tabla de interpretación completa en el documento de proyecto.") | Out-Null
    $inf.Add("====================================================================") | Out-Null
    return $inf
}

# ── Guardar en formato Excel español ──
$fecha = Get-Date -Format "yyyy-MM-dd_HHmmss"
$carpeta = Join-Path $PSScriptRoot "datos_volcados"
if (-not (Test-Path $carpeta)) { New-Item -ItemType Directory -Path $carpeta | Out-Null }
$fichero = Join-Path $carpeta "datalog_$fecha.csv"

$salida = New-Object System.Collections.Generic.List[string]
$salida.Add("sep=,")
$primera = $true
foreach ($ln in $lineas) {
    if ($primera) { $salida.Add($ln); $primera = $false; continue }
    $campos = $ln.Split(",")
    $nuevos = foreach ($c in $campos) {
        if ($c -match '^-?\d+\.\d+$') { '"' + ($c -replace '\.', ',') + '"' } else { $c }
    }
    $salida.Add(($nuevos -join ","))
}
$salida | Out-File -FilePath $fichero -Encoding UTF8

Write-Host ""
Write-Host "[OK] Volcado completado." -ForegroundColor Green
Write-Host "     Registros: $($lineas.Count - 1)" -ForegroundColor Green
Write-Host "     Fichero:   $fichero" -ForegroundColor Green

# ── Análisis básico ──
$umbrales = Get-Umbrales
$fUmbrales = Join-Path $PSScriptRoot "umbrales.txt"
if (-not (Test-Path $fUmbrales)) {
    Write-Host ""
    Write-Host "[i] No se encontró umbrales.txt: se usan los valores por defecto." -ForegroundColor Yellow
    Write-Host "    Puedes crear ese fichero para ajustarlos sin tocar el script." -ForegroundColor Gray
}

Write-Host ""
$franjas = Get-Franjas
$informe = Get-Análisis $lineas $umbrales $franjas
foreach ($l in $informe) {
    if ($l -match "INCUMPLIMIENTO|riesgo|Riesgo|<--") { Write-Host $l -ForegroundColor Yellow }
    elseif ($l -match "^====") { Write-Host $l -ForegroundColor DarkCyan }
    elseif ($l -match "^  ---") { Write-Host $l -ForegroundColor Cyan }
    else { Write-Host $l }
}

# Guardar el informe junto al CSV
$fInforme = $fichero -replace "\.csv$", "_resumen.txt"
$cabecera = @(
    "RESUMEN DE REGISTRO AMBIENTAL",
    "Generado: $(Get-Date -Format 'yyyy-MM-dd HH:mm')",
    "Datos:    $(Split-Path $fichero -Leaf)",
    "www.acusticaescolar.com",
    ""
)
($cabecera + $informe) | Out-File -FilePath $fInforme -Encoding UTF8
Write-Host ""
Write-Host "[OK] Resumen guardado en: $fInforme" -ForegroundColor Green

Read-Host "`nPulsa Enter para salir"
