# ============================================================
# volcar_datos.ps1
# Vuelca el CSV del datalogger ESP32-S3 a un fichero en el PC
# www.acusticaescolar.com - Licencia MIT
#
# Detecta automaticamente el puerto COM del ESP32 (ignora COM1
# y puertos fantasma), envia el comando 'D', captura el CSV y
# lo guarda con la fecha en el nombre.
#
# Requisitos: Windows con PowerShell (no instala nada).
# Uso: doble clic en volcar_datos.bat.
#
# IMPORTANTE: el Monitor Serie del Arduino IDE debe estar CERRADO.
# ============================================================

$ErrorActionPreference = "Stop"
$baudRate = 115200

Write-Host ""
Write-Host "=== VOLCADO DE DATOS - Datalogger ESP32-S3 ===" -ForegroundColor Cyan
Write-Host ""

# --- 1. Detectar el puerto COM del ESP32 ---
# Estrategia: buscar dispositivos USB-serie reales via WMI, que da la
# descripcion ("Dispositivo serie USB", "CH340", "CP210x", etc.).
# Se ignoran COM1/COM2 (puertos fantasma tipicos del sistema).

$puerto = $null

# Buscar por descripcion de dispositivo PnP con COMxx en el nombre
$candidatos = Get-CimInstance -ClassName Win32_PnPEntity -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -match "\(COM(\d+)\)" } |
    ForEach-Object {
        if ($_.Name -match "\(COM(\d+)\)") {
            [PSCustomObject]@{
                Nombre = $_.Name
                Com    = "COM" + $Matches[1]
                Num    = [int]$Matches[1]
            }
        }
    }

# Filtrar: quitar COM1 y COM2 (fantasma), priorizar USB/serie
$candidatos = $candidatos | Where-Object { $_.Num -gt 2 }

if ($candidatos) {
    # Priorizar los que mencionan USB, Serial, CH34, CP210, ESP, JTAG
    $preferidos = $candidatos | Where-Object {
        $_.Nombre -match "USB|Serial|Serie|CH34|CP210|ESP|JTAG|Silicon"
    }
    if ($preferidos) {
        $elegido = $preferidos | Select-Object -First 1
    } else {
        $elegido = $candidatos | Select-Object -First 1
    }
    $puerto = $elegido.Com
    Write-Host "[OK] Puerto detectado: $puerto" -ForegroundColor Green
    Write-Host "     ($($elegido.Nombre))" -ForegroundColor Gray
}

# Fallback: si WMI no dio nada, usar GetPortNames ignorando COM1/COM2
if (-not $puerto) {
    $ports = [System.IO.Ports.SerialPort]::GetPortNames() |
        Where-Object { $_ -notin @("COM1","COM2") }
    if ($ports.Count -ge 1) {
        $puerto = $ports[0]
        Write-Host "[OK] Puerto detectado (fallback): $puerto" -ForegroundColor Green
    }
}

if (-not $puerto) {
    Write-Host "[!] No se ha detectado el puerto del ESP32." -ForegroundColor Red
    Write-Host "    Verifica que esta conectado por USB." -ForegroundColor Yellow
    Read-Host "`nPulsa Enter para salir"
    exit 1
}

# --- 2. Abrir el puerto ---
try {
    $sp = New-Object System.IO.Ports.SerialPort $puerto, $baudRate, "None", 8, "One"
    $sp.ReadTimeout  = 3000
    $sp.WriteTimeout = 2000
    $sp.DtrEnable = $true
    $sp.RtsEnable = $true
    $sp.Open()
} catch {
    Write-Host "[!] No se pudo abrir $puerto." -ForegroundColor Red
    Write-Host "    Causa mas probable: el Monitor Serie del Arduino IDE esta abierto." -ForegroundColor Yellow
    Write-Host "    Cierralo y vuelve a intentarlo." -ForegroundColor Yellow
    Read-Host "`nPulsa Enter para salir"
    exit 1
}

Start-Sleep -Milliseconds 800
$sp.DiscardInBuffer()

# --- 3. Enviar el comando de volcado ---
Write-Host "[i] Solicitando volcado del CSV..." -ForegroundColor Cyan
$sp.WriteLine("D")

# --- 4. Capturar la respuesta entre las marcas ---
$lineas = New-Object System.Collections.Generic.List[string]
$capturando = $false
$finLimite = (Get-Date).AddSeconds(40)

while ((Get-Date) -lt $finLimite) {
    try {
        $linea = $sp.ReadLine()
    } catch [TimeoutException] {
        if ($capturando) { break }
        else { continue }
    }
    $linea = $linea.TrimEnd("`r")

    if ($linea -match "----- INICIO CSV -----") { $capturando = $true; continue }
    if ($linea -match "----- FIN CSV")          { break }

    if ($capturando -and $linea -notmatch "^\[LOG #") {
        $lineas.Add($linea)
    }
}

$sp.Close()

# --- 5. Guardar en fichero ---
if ($lineas.Count -eq 0) {
    Write-Host "[!] No se recibio ningun dato." -ForegroundColor Red
    Write-Host "    Verifica que el firmware corre y tiene datos (comando I)." -ForegroundColor Yellow
    Read-Host "`nPulsa Enter para salir"
    exit 1
}

$fecha = Get-Date -Format "yyyy-MM-dd_HHmmss"
$carpeta = Join-Path $PSScriptRoot "datos_volcados"
if (-not (Test-Path $carpeta)) { New-Item -ItemType Directory -Path $carpeta | Out-Null }
$fichero = Join-Path $carpeta "datalog_$fecha.csv"

# --- Preparar salida para Excel en espanol ---
# 1. Linea 'sep=,' para que Excel use la coma como separador de columnas.
# 2. Decimales con coma: los campos numericos con punto decimal se convierten
#    a coma y se entrecomillan, para que Excel no confunda la coma decimal
#    con el separador de columnas.
$salida = New-Object System.Collections.Generic.List[string]
$salida.Add("sep=,")

$primera = $true
foreach ($ln in $lineas) {
    if ($primera) {
        # cabecera: se deja tal cual (nombres de columna, sin decimales)
        $salida.Add($ln)
        $primera = $false
        continue
    }
    # Procesar cada campo de la fila
    $campos = $ln.Split(",")
    $nuevos = foreach ($c in $campos) {
        if ($c -match '^-?\d+\.\d+$') {
            # numero con punto decimal -> coma decimal, entrecomillado
            '"' + ($c -replace '\.', ',') + '"'
        } else {
            $c
        }
    }
    $salida.Add(($nuevos -join ","))
}

$salida | Out-File -FilePath $fichero -Encoding UTF8

Write-Host ""
Write-Host "[OK] Volcado completado." -ForegroundColor Green
Write-Host "     Registros guardados: $($lineas.Count - 1)" -ForegroundColor Green
Write-Host "     Fichero: $fichero" -ForegroundColor Green
Write-Host ""
Write-Host "Primeras lineas:" -ForegroundColor Cyan
$lineas | Select-Object -First 4 | ForEach-Object { Write-Host "    $_" }

Read-Host "`nPulsa Enter para salir"
