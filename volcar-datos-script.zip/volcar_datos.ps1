# ============================================================
# volcar_datos.ps1
# Vuelca el CSV del Registrador Ambiental a un fichero en el PC
# www.acusticaescolar.com - Licencia MIT
#
# Uso normal:     doble clic en volcar_datos.bat
# Puerto manual:  volcar_datos.bat COM3
# Diagnostico:    volcar_datos.bat COM3 -Verbose
#
# IMPORTANTE: el Monitor Serie del Arduino IDE debe estar CERRADO.
# ============================================================

param(
    [string]$Puerto = "",
    [switch]$Verbose
)

$ErrorActionPreference = "Stop"
$baudRate = 115200

Write-Host ""
Write-Host "=== VOLCADO DE DATOS - Registrador Ambiental ===" -ForegroundColor Cyan
Write-Host ""

# ── Localizar puertos candidatos ──
function Get-Candidatos {
    $lista = @()
    try {
        $disp = Get-CimInstance -ClassName Win32_PnPEntity -ErrorAction SilentlyContinue |
                Where-Object { $_.Name -match "\(COM(\d+)\)" }
        foreach ($d in $disp) {
            if ($d.Name -match "\(COM(\d+)\)") {
                $lista += [PSCustomObject]@{
                    Com         = "COM" + $Matches[1]
                    Nombre      = $d.Name
                    Prioritario = ($d.DeviceID -match "VID_(303A|1A86|10C4|0403)")
                }
            }
        }
    } catch { }
    # Fabricante conocido primero
    return @($lista | Where-Object { $_.Prioritario }) +
           @($lista | Where-Object { -not $_.Prioritario })
}

# ── Abrir puerto y esperar a que el dispositivo este LISTO ──
# Al abrir el puerto, la placa puede reiniciarse (senal DTR). Si eso ocurre,
# el firmware ejecuta su diagnostico de arranque durante unos segundos y no
# atiende comandos. Esta funcion espera a que termine antes de continuar.
function Open-Registrador {
    param([string]$com)

    $sp = New-Object System.IO.Ports.SerialPort $com, $baudRate, "None", 8, "One"
    $sp.ReadTimeout  = 1500
    $sp.WriteTimeout = 2000
    $sp.DtrEnable = $true
    $sp.RtsEnable = $true
    $sp.ReadBufferSize = 65536      # holgado: el volcado puede ser largo
    $sp.Open()

    Write-Host "      esperando a que el equipo este listo..." -ForegroundColor Gray
    $arrancando = $false
    $listo      = $false
    $limite = (Get-Date).AddSeconds(30)

    while ((Get-Date) -lt $limite) {
        try { $l = $sp.ReadLine().TrimEnd("`r") }
        catch [TimeoutException] {
            # Silencio: si ya vimos el arranque, es que termino; si no, probamos
            if ($arrancando) { $listo = $true; break }
            $sp.WriteLine("H")       # tantear con un comando inofensivo
            continue
        }
        if ($Verbose) { Write-Host "        < $l" -ForegroundColor DarkGray }

        # El equipo se ha reiniciado: hay que esperar al final del diagnostico
        if ($l -match "DATALOGGER AMBIENTAL|FASE 1|Iniciando") { $arrancando = $true }
        # Senales de que ya esta operativo y atiende comandos
        if ($l -match "Comandos:|componentes OK|Hora del RTC|\[LOG #|Ventana de registro") {
            $listo = $true; break
        }
    }
    if (-not $listo) { Write-Host "      (sin confirmacion, se intenta igualmente)" -ForegroundColor DarkYellow }
    Start-Sleep -Milliseconds 500
    $sp.DiscardInBuffer()
    return $sp
}

# ── Determinar el puerto ──
if ($Puerto -ne "") {
    $puertoElegido = $Puerto
    Write-Host "[i] Puerto indicado manualmente: $puertoElegido" -ForegroundColor Yellow
} else {
    $cand = Get-Candidatos
    if ($cand.Count -eq 0) {
        Write-Host "[!] No se ha detectado ningun puerto COM." -ForegroundColor Red
        Write-Host "    Verifica que el registrador esta conectado por USB." -ForegroundColor Yellow
        Read-Host "`nPulsa Enter para salir"; exit 1
    }
    Write-Host "[i] Puertos detectados:" -ForegroundColor Cyan
    foreach ($c in $cand) {
        $m = if ($c.Prioritario) { " <- chip USB-serie conocido" } else { "" }
        Write-Host "      $($c.Nombre)$m" -ForegroundColor Gray
    }
    $puertoElegido = $cand[0].Com
    Write-Host ""
    Write-Host "[i] Usando $puertoElegido" -ForegroundColor Cyan
}

# ── Abrir (una sola vez) ──
try {
    $sp = Open-Registrador $puertoElegido
} catch {
    Write-Host ""
    Write-Host "[!] No se pudo abrir $puertoElegido." -ForegroundColor Red
    Write-Host "    Causas mas probables:" -ForegroundColor Yellow
    Write-Host "      - El Monitor Serie del Arduino IDE esta abierto. Cierralo." -ForegroundColor Yellow
    Write-Host "      - Otro programa esta usando el puerto." -ForegroundColor Yellow
    Write-Host "    Puedes indicar otro puerto:  volcar_datos.bat COM3" -ForegroundColor White
    Read-Host "`nPulsa Enter para salir"; exit 1
}

Write-Host "[OK] Conectado a $puertoElegido" -ForegroundColor Green
Write-Host ""

# ── Solicitar el volcado (con reintentos) ──
$lineas = New-Object System.Collections.Generic.List[string]
$recibidoAlgo = $false

for ($intento = 1; $intento -le 3; $intento++) {
    Write-Host "[i] Solicitando volcado del CSV (intento $intento de 3)..." -ForegroundColor Cyan
    $sp.DiscardInBuffer()
    $sp.WriteLine("D")

    $capturando = $false
    $sp.ReadTimeout = 5000
    $limite = (Get-Date).AddSeconds(90)

    while ((Get-Date) -lt $limite) {
        try { $linea = $sp.ReadLine().TrimEnd("`r") }
        catch [TimeoutException] { if ($capturando) { break } else { break } }
        $recibidoAlgo = $true
        if ($Verbose) { Write-Host "    < $linea" -ForegroundColor DarkGray }

        if ($linea -match "----- INICIO CSV -----") { $capturando = $true; continue }
        if ($linea -match "----- FIN CSV")          { break }
        if ($linea -match "No hay CSV") {
            Write-Host "[!] El equipo responde que no hay datos guardados." -ForegroundColor Yellow
            $sp.Close(); Read-Host "`nPulsa Enter para salir"; exit 1
        }
        if ($capturando -and $linea -notmatch "^\[LOG #") { $lineas.Add($linea) }
    }
    if ($lineas.Count -gt 0) { break }
    Write-Host "      sin respuesta util, reintentando..." -ForegroundColor DarkYellow
    Start-Sleep -Seconds 2
}
$sp.Close()

if ($lineas.Count -eq 0) {
    Write-Host ""
    Write-Host "[!] No se recibieron datos." -ForegroundColor Red
    if ($recibidoAlgo) {
        Write-Host "    El equipo respondia, pero no envio el bloque de datos." -ForegroundColor Yellow
        Write-Host "    Comprueba con el comando I (en el Monitor Serie) que hay" -ForegroundColor Yellow
        Write-Host "    registros guardados." -ForegroundColor Yellow
    } else {
        Write-Host "    El equipo no respondio en absoluto." -ForegroundColor Yellow
        Write-Host "    Prueba a desconectar y reconectar el cable USB." -ForegroundColor Yellow
    }
    Write-Host ""
    Write-Host "    Para ver el detalle de la comunicacion:" -ForegroundColor White
    Write-Host "      volcar_datos.bat $puertoElegido -Verbose" -ForegroundColor White
    Read-Host "`nPulsa Enter para salir"; exit 1
}

# ── Guardar en formato Excel espanol ──
$fecha = Get-Date -Format "yyyy-MM-dd_HHmmss"
$carpeta = Join-Path $PSScriptRoot "datos_volcados"
if (-not (Test-Path $carpeta)) { New-Item -ItemType Directory -Path $carpeta | Out-Null }
$fichero = Join-Path $carpeta "datalog_$fecha.csv"

$salida = New-Object System.Collections.Generic.List[string]
$salida.Add("sep=,")
$primera = $true
foreach ($ln in $lineas) {
    if ($primera) { $salida.Add($ln); $primera = $false; continue }
    $campos = $ln.Split(",")
    $nuevos = foreach ($c in $campos) {
        if ($c -match '^-?\d+\.\d+$') { '"' + ($c -replace '\.', ',') + '"' } else { $c }
    }
    $salida.Add(($nuevos -join ","))
}
$salida | Out-File -FilePath $fichero -Encoding UTF8

Write-Host ""
Write-Host "[OK] Volcado completado." -ForegroundColor Green
Write-Host "     Registros: $($lineas.Count - 1)" -ForegroundColor Green
Write-Host "     Fichero:   $fichero" -ForegroundColor Green
Write-Host ""
Write-Host "Primeras lineas:" -ForegroundColor Cyan
$lineas | Select-Object -First 4 | ForEach-Object { Write-Host "    $_" }

Read-Host "`nPulsa Enter para salir"
